const state = {
  analysis: null,
  filteredReviews: []
};

const controls = {
  search: document.getElementById("searchInput"),
  sentiment: document.getElementById("sentimentFilter"),
  emotion: document.getElementById("emotionFilter"),
  aspect: document.getElementById("aspectFilter"),
  source: document.getElementById("sourceFilter"),
  rating: document.getElementById("ratingFilter"),
  sort: document.getElementById("sortSelect"),
  reset: document.getElementById("resetFiltersButton"),
  exportCsv: document.getElementById("exportCsvButton"),
  copyReport: document.getElementById("copyReportButton")
};

function getAnalysisId() {
  const parts = window.location.pathname.split("/").filter(Boolean);
  return parts[0] === "report" ? parts[1] : null;
}

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

function createTextElement(tagName, text, className = "") {
  const element = document.createElement(tagName);
  if (className) element.className = className;
  element.textContent = text;
  return element;
}

function reviewAspects(review) {
  return (review.aspects || []).map((aspect) => aspect.label).filter(Boolean);
}

function sentimentClass(sentiment) {
  if (sentiment === "негатив") return "negative";
  if (sentiment === "позитив") return "positive";
  return "neutral";
}

function renderBars(containerId, data) {
  const container = document.getElementById(containerId);
  container.innerHTML = "";
  const entries = Object.entries(data || {});
  const max = Math.max(...entries.map(([, value]) => value), 1);

  if (entries.length === 0) {
    container.textContent = "Нет данных";
    return;
  }

  for (const [label, value] of entries) {
    const row = document.createElement("div");
    row.className = "bar-row";
    const labelEl = createTextElement("span", label);
    const track = document.createElement("div");
    track.className = "track";
    const fill = document.createElement("div");
    fill.className = "fill";
    fill.style.width = `${(value / max) * 100}%`;
    track.appendChild(fill);
    const valueEl = createTextElement("strong", value);
    row.append(labelEl, track, valueEl);
    container.appendChild(row);
  }
}

function renderProblems(problems) {
  const container = document.getElementById("problems");
  container.innerHTML = "";

  if (!problems || problems.length === 0) {
    container.textContent = "Выраженных проблемных аспектов не найдено.";
    return;
  }

  for (const problem of problems) {
    const element = document.createElement("article");
    element.className = "problem";
    element.appendChild(createTextElement("h3", problem.aspect));
    element.appendChild(createTextElement("p", `Негативных упоминаний: ${problem.negative_reviews}`));

    for (const example of problem.examples || []) {
      element.appendChild(createTextElement("p", `Пример: ${example}`));
    }

    element.appendChild(createTextElement("p", `Рекомендация: ${problem.recommendation}`));
    container.appendChild(element);
  }
}

function renderStrengths(strengths) {
  const container = document.getElementById("strengths");
  container.innerHTML = "";

  if (!strengths || strengths.length === 0) {
    container.textContent = "Сильные стороны пока не выражены явно.";
    return;
  }

  for (const strength of strengths) {
    const element = document.createElement("article");
    element.className = "strength";
    element.appendChild(createTextElement("h3", strength.aspect));
    element.appendChild(createTextElement("p", `Позитивных упоминаний: ${strength.positive_reviews}`));

    for (const example of strength.examples || []) {
      element.appendChild(createTextElement("p", `Пример: ${example}`));
    }

    element.appendChild(createTextElement("p", `Как использовать: ${strength.recommendation}`));
    container.appendChild(element);
  }
}

function addOption(select, value, label) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = label;
  select.appendChild(option);
}

function fillSelect(select, values, allLabel) {
  select.innerHTML = "";
  addOption(select, "", allLabel);
  for (const value of values) {
    addOption(select, value, value);
  }
}

function uniqueSorted(values) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b, "ru"));
}

function populateFilters(analysis) {
  const reviews = analysis.reviews || [];
  fillSelect(controls.sentiment, uniqueSorted(reviews.map((review) => review.sentiment)), "Любая");
  fillSelect(controls.emotion, uniqueSorted(reviews.map((review) => review.emotion?.label)), "Любая");
  fillSelect(controls.aspect, uniqueSorted(reviews.flatMap(reviewAspects)), "Все аспекты");
  fillSelect(controls.source, uniqueSorted(reviews.map((review) => review.source)), "Все источники");
}

function getFilters() {
  return {
    query: controls.search.value.trim().toLowerCase(),
    sentiment: controls.sentiment.value,
    emotion: controls.emotion.value,
    aspect: controls.aspect.value,
    source: controls.source.value,
    rating: Number(controls.rating.value || 0),
    sort: controls.sort.value
  };
}

function matchesFilters(review, filters) {
  const searchable = [
    review.text,
    review.source,
    review.sentiment,
    review.emotion?.label,
    ...reviewAspects(review)
  ].join(" ").toLowerCase();

  if (filters.query && !searchable.includes(filters.query)) return false;
  if (filters.sentiment && review.sentiment !== filters.sentiment) return false;
  if (filters.emotion && review.emotion?.label !== filters.emotion) return false;
  if (filters.aspect && !reviewAspects(review).includes(filters.aspect)) return false;
  if (filters.source && review.source !== filters.source) return false;
  if (filters.rating && !(Number(review.rating || 0) >= filters.rating)) return false;
  return true;
}

function sortReviews(reviews, sortMode) {
  const copy = [...reviews];
  const sentimentRank = { негатив: 0, нейтрально: 1, позитив: 2 };

  if (sortMode === "ratingAsc") {
    return copy.sort((a, b) => Number(a.rating ?? 99) - Number(b.rating ?? 99));
  }
  if (sortMode === "ratingDesc") {
    return copy.sort((a, b) => Number(b.rating ?? -1) - Number(a.rating ?? -1));
  }
  if (sortMode === "source") {
    return copy.sort((a, b) => String(a.source).localeCompare(String(b.source), "ru"));
  }

  return copy.sort((a, b) => {
    const sentimentDelta = (sentimentRank[a.sentiment] ?? 1) - (sentimentRank[b.sentiment] ?? 1);
    if (sentimentDelta !== 0) return sentimentDelta;
    return Number(a.rating ?? 99) - Number(b.rating ?? 99);
  });
}

function renderFilterSummary(reviews) {
  const ratings = reviews.map((review) => review.rating).filter((rating) => typeof rating === "number");
  const average = ratings.length ? (ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length).toFixed(2) : "-";
  setText("filteredReviews", reviews.length);
  setText("filteredNegative", reviews.filter((review) => review.sentiment === "негатив").length);
  setText("filteredPositive", reviews.filter((review) => review.sentiment === "позитив").length);
  setText("filteredAverage", average);
  setText("reviewCounter", `Показано ${reviews.length} из ${state.analysis?.reviews?.length || 0}`);
}

function renderActiveFilters(filters) {
  const container = document.getElementById("activeFilters");
  container.innerHTML = "";
  const chips = [];
  if (filters.query) chips.push(`поиск: ${filters.query}`);
  if (filters.sentiment) chips.push(`тональность: ${filters.sentiment}`);
  if (filters.emotion) chips.push(`эмоция: ${filters.emotion}`);
  if (filters.aspect) chips.push(`аспект: ${filters.aspect}`);
  if (filters.source) chips.push(`источник: ${filters.source}`);
  if (filters.rating) chips.push(`оценка от ${filters.rating}`);

  if (chips.length === 0) {
    container.appendChild(createTextElement("span", "без фильтров", "chip"));
    return;
  }

  for (const chip of chips) {
    container.appendChild(createTextElement("span", chip, "chip"));
  }
}

function renderReviews(reviews) {
  const tbody = document.getElementById("reviewsTable");
  tbody.innerHTML = "";

  if (reviews.length === 0) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.className = "empty-state";
    cell.colSpan = 5;
    cell.textContent = "По этим фильтрам отзывов нет.";
    row.appendChild(cell);
    tbody.appendChild(row);
    return;
  }

  for (const review of reviews) {
    const row = document.createElement("tr");
    row.className = `is-${sentimentClass(review.sentiment)}`;

    row.appendChild(createTextElement("td", review.source || "-"));
    row.appendChild(createTextElement("td", review.rating ?? "-"));
    row.appendChild(createTextElement("td", review.text || ""));

    const emotionCell = document.createElement("td");
    emotionCell.appendChild(createTextElement("strong", review.emotion?.label || "-"));
    emotionCell.appendChild(createTextElement("span", review.sentiment || "нейтрально", `sentiment-pill ${sentimentClass(review.sentiment)}`));
    row.appendChild(emotionCell);

    const aspectCell = document.createElement("td");
    for (const label of reviewAspects(review)) {
      aspectCell.appendChild(createTextElement("span", label, "badge"));
    }
    row.appendChild(aspectCell);

    tbody.appendChild(row);
  }
}

function applyFilters() {
  if (!state.analysis) return;
  const filters = getFilters();
  const filtered = sortReviews(
    (state.analysis.reviews || []).filter((review) => matchesFilters(review, filters)),
    filters.sort
  );
  state.filteredReviews = filtered;
  renderFilterSummary(filtered);
  renderActiveFilters(filters);
  renderReviews(filtered);
}

function resetFilters() {
  controls.search.value = "";
  controls.sentiment.value = "";
  controls.emotion.value = "";
  controls.aspect.value = "";
  controls.source.value = "";
  controls.rating.value = "";
  controls.sort.value = "risk";
  applyFilters();
}

function csvEscape(value) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

function exportFilteredCsv() {
  const rows = [
    ["Источник", "Оценка", "Отзыв", "Эмоция", "Тональность", "Аспекты"],
    ...state.filteredReviews.map((review) => [
      review.source,
      review.rating ?? "",
      review.text,
      review.emotion?.label || "",
      review.sentiment || "",
      reviewAspects(review).join("; ")
    ])
  ];
  const csv = rows.map((row) => row.map(csvEscape).join(";")).join("\n");
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `reviews-report-${getAnalysisId() || "export"}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

async function copyReportLink() {
  try {
    await navigator.clipboard.writeText(window.location.href);
    controls.copyReport.textContent = "Готово";
    setTimeout(() => {
      controls.copyReport.textContent = "Ссылка";
    }, 1200);
  } catch (error) {
    controls.copyReport.textContent = "Ошибка";
  }
}

async function loadReport() {
  const id = getAnalysisId();
  if (!id) {
    setText("objectMeta", "Открой отчет из расширения после анализа страницы.");
    return;
  }

  const response = await fetch(`/api/analysis/${id}`);
  if (!response.ok) {
    setText("objectMeta", "Отчет не найден.");
    return;
  }

  const analysis = await response.json();
  state.analysis = analysis;

  setText("objectName", analysis.object.name);
  setText(
    "objectMeta",
    `${analysis.object.type} · уверенность анализа ${Math.round(analysis.summary.confidence * 100)}%`
  );
  setText("sourceInfo", analysis.source ? analysis.source.message : "");
  setText("totalReviews", analysis.summary.total_reviews);
  setText("averageRating", analysis.summary.average_rating ?? "-");
  setText("dominantEmotion", analysis.summary.dominant_emotion);
  setText("dominantSentiment", analysis.summary.dominant_sentiment);
  setText("riskLevel", analysis.summary.risk_level || "-");
  setText("executiveSummary", analysis.summary.executive_summary || "");
  setText("nextStep", analysis.summary.next_step || "");

  renderBars("emotionBars", analysis.distributions.emotions);
  renderBars("aspectBars", analysis.distributions.aspects);
  renderStrengths(analysis.strength_aspects);
  renderProblems(analysis.problem_aspects);
  populateFilters(analysis);
  applyFilters();
}

for (const control of [
  controls.search,
  controls.sentiment,
  controls.emotion,
  controls.aspect,
  controls.source,
  controls.rating,
  controls.sort
]) {
  control.addEventListener("input", applyFilters);
  control.addEventListener("change", applyFilters);
}

controls.reset.addEventListener("click", resetFilters);
controls.exportCsv.addEventListener("click", exportFilteredCsv);
controls.copyReport.addEventListener("click", copyReportLink);

loadReport();
