function textOf(selector) {
  const element = document.querySelector(selector);
  return element ? element.textContent.trim() : "";
}

function metaContent(name) {
  const element =
    document.querySelector(`meta[name="${name}"]`) ||
    document.querySelector(`meta[property="${name}"]`);
  return element ? element.getAttribute("content") || "" : "";
}

function isVisible(element) {
  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

const reviewStartPattern = /(?:^|\s)(?:[А-ЯЁA-Z]\s+)?[А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Z]\.)?\s+\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+20\d{2}/gi;

function cleanReviewText(text) {
  return text
    .replace(/\s+/g, " ")
    .replace(/Вам помог(?:\s+этот)?\s+отзыв\?\s*Да\s*\d+\s*Нет\s*\d+/gi, " ")
    .replace(/Отзыв выбран компанией/gi, " ")
    .replace(/Отзыв подтвержд[её]н/gi, " ")
    .replace(/\d+\s+посещени[еяй]/gi, " ")
    .replace(/Полезно\?/gi, " ")
    .replace(/\b(?:Российский размер|Размер производителя)\s*:\s*\S+[,;]?\s*/gi, " ")
    .replace(/\b(?:Цвет товара|Название цвета|Комплектация|Артикул|Бренд)\s*:\s*[^,.;!?]{1,70}[,;]?\s*/gi, " ")
    .replace(/\b(?:Достоинства|Недостатки|Комментарий)\s*:\s*/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isNoiseBlock(text) {
  const normalized = text.replace(/\s+/g, " ").trim();
  const lowered = normalized.toLowerCase();
  const subscribeCount = (normalized.match(/Подписаться/gi) || []).length;
  const expertCount = (normalized.match(/Знаток города|Пишет отзывы|Оставляет отзывы|Разбирается|Часто пишет|Много отзывов/gi) || []).length;

  return (
    /^,?\s*официальный ответ\b/i.test(normalized) ||
    /\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+20\d{2},\s*официальный ответ/i.test(normalized) ||
    lowered.startsWith("рекомендации для вас") ||
    lowered.includes("показать все") && subscribeCount >= 2 ||
    subscribeCount >= 3 ||
    expertCount >= 2
  );
}

function splitReviewBlob(text) {
  const normalized = text.replace(/\s+/g, " ").trim();
  const starts = [];
  for (const match of normalized.matchAll(reviewStartPattern)) {
    starts.push(match.index);
  }
  if (starts.length <= 1) return [normalized];

  starts.push(normalized.length);
  return starts
    .slice(0, -1)
    .map((start, index) => normalized.slice(start, starts[index + 1]).trim())
    .filter(Boolean);
}

function looksLikeReviewText(text) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (normalized.length < 12 || normalized.length > 1800) return false;
  if (isNoiseBlock(normalized)) return false;

  const lowered = normalized.toLowerCase();
  const usefulMarkers = [
    /достоинства/i,
    /недостатки/i,
    /комментарий/i,
    /рекомендую/i,
    /не рекомендую/i,
    /понрав/i,
    /вкусн/i,
    /качество/i,
    /обслуж/i,
    /персонал/i,
    /достав/i,
    /цена/i,
    /заказ/i,
    /купил/i,
    /купила/i,
    /товар/i,
    /место/i,
    /кафе/i,
    /бургер/i,
    /пицц/i,
    /шланг/i,
    /полив/i,
    /метр/i,
    /давлен/i,
    /теч[её]/i,
    /протека/i,
    /хороший/i,
    /плохой/i,
    /отличный/i
  ];
  const uiOnly = [
    /рекомендации для вас/i,
    /подписаться/i,
    /показать все/i,
    /знаток города/i,
    /похожие места/i,
    /вам может понравиться/i,
    /реклама/i
  ];

  if (uiOnly.some((pattern) => pattern.test(lowered))) return false;
  if (usefulMarkers.some((pattern) => pattern.test(lowered))) return true;
  return normalized.split(/[.!?]+/).filter((part) => part.trim().length > 18).length >= 2;
}

function addCandidate(candidates, element, source, options = {}) {
  if (!element || !isVisible(element)) return;
  const rawText = (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
  if (!rawText) return;
  if (options.maxLength && rawText.length > options.maxLength) return;
  if (isNoiseBlock(rawText)) return;
  candidates.push({ text: rawText, source, priority: options.priority || 0 });
}

function collectPlainTextReviewCandidates() {
  const bodyText = (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  if (!bodyText) return [];

  const candidates = [];
  for (const part of splitReviewBlob(bodyText)) {
    if (part.length >= 25 && part.length <= 1800 && looksLikeReviewText(cleanReviewText(part))) {
      candidates.push({ text: part, source: "visible_page_text", priority: 0 });
    }
  }

  const markerPattern = /(?:Достоинства|Недостатки|Комментарий)\s*:?\s*/gi;
  const markerStarts = [];
  for (const match of bodyText.matchAll(markerPattern)) {
    markerStarts.push(match.index);
  }

  for (const start of markerStarts) {
    const before = Math.max(0, start - 180);
    const after = Math.min(bodyText.length, start + 900);
    const snippet = bodyText.slice(before, after).trim();
    if (snippet.length >= 25 && looksLikeReviewText(cleanReviewText(snippet))) {
      candidates.push({ text: snippet, source: "visible_page_text", priority: 0 });
    }
  }

  return candidates;
}

function collect2GisReviewCandidates() {
  const bodyText = (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  if (!bodyText || !/2gis|2гис|отзывы|оценок/i.test(`${location.hostname} ${document.title} ${bodyText.slice(0, 1500)}`)) {
    return [];
  }

  const monthPattern = "января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря";
  const datePattern = `\\d{1,2}\\s+(?:${monthPattern})\\s+20\\d{2}`;
  const reviewPattern = new RegExp(
    `(?:^|\\s)([A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?)\\s+` +
      `(?:\\d+\\s+отзыв(?:ов|а)?\\s+)?` +
      `(${datePattern}(?:,\\s*(?:измен[её]н|официальный ответ))?)\\s+` +
      `([\\s\\S]*?)` +
      `(?=\\s+[A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?\\s+(?:\\d+\\s+отзыв(?:ов|а)?\\s+)?${datePattern}|$)`,
    "gi"
  );

  const candidates = [];
  const seen = new Set();
  let match;
  while ((match = reviewPattern.exec(bodyText)) && candidates.length < 300) {
    const dateText = match[2] || "";
    if (/официальный ответ/i.test(dateText)) continue;

    let text = cleanReviewText(match[3] || "")
      .replace(/Читать целиком/gi, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (/официальный ответ/i.test(text)) continue;
    text = text.replace(/(?:\s+\d+){1,4}$/g, "").trim();
    if (text.length < 5 || text.length > 1000 || isNoiseBlock(text)) continue;

    const fingerprint = text.toLowerCase().slice(0, 180);
    if (seen.has(fingerprint)) continue;
    seen.add(fingerprint);
    candidates.push({ text, source: "2gis_visible_text", priority: 4 });
  }

  return candidates;
}

function collectYandexEdaReviewCandidates() {
  const bodyText = (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  if (!bodyText || !/eda\.yandex|Я\.Еда|Яндекс Еда|Рейтинг Я\.Еды/i.test(`${location.hostname} ${document.title} ${bodyText.slice(0, 1800)}`)) {
    return [];
  }

  const monthPattern = "января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря";
  const datePattern = `\\d{1,2}\\s+(?:${monthPattern})(?:\\s+20\\d{2})?`;
  const reviewPattern = new RegExp(
    `(?:^|\\s)([A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?)\\s+` +
      `(${datePattern}\\s*·\\s*(?:Я\\.Еда|Я\\.Карты|Яндекс\\.Еда|Яндекс\\.Карты))\\s+` +
      `([\\s\\S]*?)` +
      `(?=\\s+[A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?\\s+${datePattern}\\s*·\\s*(?:Я\\.Еда|Я\\.Карты|Яндекс\\.Еда|Яндекс\\.Карты)|$)`,
    "gi"
  );

  const candidates = [];
  const seen = new Set();
  let match;
  while ((match = reviewPattern.exec(bodyText)) && candidates.length < 300) {
    let text = cleanReviewText(match[3] || "")
      .replace(/Ответ ресторана[\s\S]*$/i, " ")
      .replace(/Рейтинг\s+Рейтинг Я\.Еды[\s\S]*$/i, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (isNoiseBlock(text) || text.length < 5 || text.length > 1000) continue;
    const fingerprint = text.toLowerCase().slice(0, 180);
    if (seen.has(fingerprint)) continue;
    seen.add(fingerprint);
    candidates.push({ text, source: "yandex_eda_modal", priority: 4 });
  }

  return candidates;
}

function collectTopHotelsReviewCandidates() {
  const bodyText = (document.body ? document.body.innerText : "").replace(/\s+/g, " ").trim();
  if (!bodyText || !/tophotels\.ru|TopHotels|ТопХотелс|ОТЗЫВЫ И ОЦЕНКИ/i.test(`${location.hostname} ${document.title} ${bodyText.slice(0, 1800)}`)) {
    return [];
  }

  const reviewPattern = /(?:^|\s)(\d[.,]\d{2})\s+\d\s*РАЗМЕЩЕНИЕ\s+\d\s*СЕРВИС\s+\d\s*ПИТАНИЕ\s+20\d{2}\s+[А-ЯЁ]+\s+([\s\S]*?)\s+(\d{2}\.\d{2}\.\d{4})\s+(?:Корректный отзыв|Мини оценка|\/ МИНИ ОЦЕНКА)/gi;
  const candidates = [];
  const seen = new Set();
  let match;

  while ((match = reviewPattern.exec(bodyText)) && candidates.length < 300) {
    let text = cleanReviewText(match[2] || "")
      .replace(/ИНФОПОВОДЫ ОТЕЛЕЙ ТОПХОТЕЛС[\s\S]*$/i, " ")
      .replace(/РЕКЛАМА[\s\S]*$/i, " ")
      .replace(/\.\.\.$/, "")
      .replace(/\s+/g, " ")
      .trim();

    if (/МИНИ ОЦЕНКА/i.test(text)) continue;
    if (text.length < 40 || text.length > 1800 || isNoiseBlock(text)) continue;

    const fingerprint = text.toLowerCase().slice(0, 220);
    if (seen.has(fingerprint)) continue;
    seen.add(fingerprint);

    const rating = Number(String(match[1] || "").replace(",", "."));
    candidates.push({
      text,
      rating: Number.isFinite(rating) ? Math.round(rating) : null,
      source: "tophotels_visible_text",
      priority: 4
    });
  }

  return candidates;
}

function collectVisibleReviews() {
  const textSelectors = [
    "[itemprop='reviewBody']",
    "[class*='business-review-view__body-text' i]",
    "[class*='business-review-view__comment' i]",
    "[class*='business-review-view__text' i]",
    "[data-review-id] [class*='text' i]",
    "[data-review-id] [class*='content' i]",
    "[data-widget*='review' i] [class*='text' i]",
    "[data-widget*='review' i] [class*='content' i]"
  ];
  const cardSelectors = [
    "[data-review-id]",
    "[itemprop='review']",
    "[class*='business-review-view' i]",
    "[data-widget*='review' i] article",
    "article"
  ];
  const candidates = [];

  candidates.push(...collect2GisReviewCandidates());
  candidates.push(...collectYandexEdaReviewCandidates());
  candidates.push(...collectTopHotelsReviewCandidates());

  for (const selector of textSelectors) {
    for (const element of document.querySelectorAll(selector)) {
      addCandidate(candidates, element, "visible_page", { priority: 3, maxLength: 1600 });
    }
  }

  for (const selector of cardSelectors) {
    for (const element of document.querySelectorAll(selector)) {
      const childReviewText = textSelectors.some((textSelector) => {
        const child = element.querySelector(textSelector);
        return child && child !== element && isVisible(child);
      });
      if (childReviewText) continue;
      addCandidate(candidates, element, "visible_page", { priority: 1, maxLength: 2600 });
    }
  }

  candidates.push(...collectPlainTextReviewCandidates());

  const reviews = [];
  const seen = new Set();
  const sortedCandidates = candidates.sort((a, b) => b.priority - a.priority || a.text.length - b.text.length);

  for (const candidate of sortedCandidates) {
    for (const part of splitReviewBlob(candidate.text)) {
      const text = cleanReviewText(part);
      if (isNoiseBlock(text)) continue;
      if (candidate.source === "2gis_visible_text" || candidate.source === "yandex_eda_modal" || candidate.source === "tophotels_visible_text") {
        if (text.length < 5) continue;
      } else if (!looksLikeReviewText(text)) {
        continue;
      }
      if (reviews.some((review) => review.text.includes(text) || text.includes(review.text))) continue;
      const fingerprint = text.toLowerCase().slice(0, 180);
      if (seen.has(fingerprint)) continue;
      seen.add(fingerprint);
      reviews.push({ source: candidate.source, text, rating: candidate.rating ?? null });
      if (reviews.length >= 300) return reviews;
    }
  }

  return reviews;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function clickableText(element) {
  return (element.innerText || element.textContent || "").replace(/\s+/g, " ").trim();
}

function clickByText(patterns) {
  const elements = Array.from(document.querySelectorAll("button, a, [role='button'], [tabindex='0']"));
  let clicked = 0;

  for (const element of elements) {
    if (!isVisible(element)) continue;
    const text = clickableText(element);
    if (!text || text.length > 90) continue;
    if (isNoiseBlock(text)) continue;
    if (!patterns.some((pattern) => pattern.test(text))) continue;

    try {
      element.scrollIntoView({ block: "center", inline: "nearest" });
      element.click();
      clicked += 1;
      if (clicked >= 4) break;
    } catch (error) {
      // Some site controls are synthetic and can reject direct clicks.
    }
  }

  return clicked;
}

function scrollCandidateContainers() {
  const containers = [document.scrollingElement, document.documentElement, document.body]
    .concat(Array.from(document.querySelectorAll("main, section, aside, [role='main'], [role='dialog'], [aria-modal='true'], [class*='modal' i], [class*='popup' i], [class*='drawer' i], [class*='scroll' i], [class*='list' i], [class*='review' i]")))
    .filter(Boolean)
    .filter((element, index, array) => array.indexOf(element) === index)
    .filter((element) => {
      if (element === document.body || element === document.documentElement || element === document.scrollingElement) {
        return true;
      }
      if (!isVisible(element)) return false;
      return element.scrollHeight > element.clientHeight + 120;
    });

  for (const container of containers) {
    try {
      const step = Math.max(420, Math.floor((container.clientHeight || window.innerHeight) * 0.85));
      container.scrollTop = Math.min(container.scrollTop + step, container.scrollHeight);
    } catch (error) {
      // Ignore containers that do not allow programmatic scrolling.
    }
  }

  window.scrollBy({ top: Math.max(520, window.innerHeight * 0.8), behavior: "auto" });
}

async function deepCollectReviews() {
  const openReviewPatterns = [
    /^отзывы$/i,
    /все\s+отзывы/i,
    /читать\s+отзывы/i,
    /показать\s+отзывы/i,
    /\d+\s+отзыв/i,
    /\d+[,.]\d\s*·\s*\d+\s+оцен/i,
    /рейтинг\s+я\./i
  ];
  const morePatterns = [
    /показать\s+ещ[её]/i,
    /ещ[её]\s+отзывы/i,
    /загрузить\s+ещ[её]/i,
    /читать\s+ещ[её]/i,
    /смотреть\s+больше/i,
    /развернуть/i,
    /далее/i
  ];

  clickByText(openReviewPatterns);
  await delay(900);

  let bestReviews = collectVisibleReviews();
  let stagnantIterations = 0;

  for (let index = 0; index < 36; index += 1) {
    clickByText(morePatterns);
    scrollCandidateContainers();
    await delay(650);

    const currentReviews = collectVisibleReviews();
    if (currentReviews.length > bestReviews.length) {
      bestReviews = currentReviews;
      stagnantIterations = 0;
    } else {
      stagnantIterations += 1;
    }

    if (bestReviews.length >= 300 || stagnantIterations >= 7) {
      break;
    }
  }

  window.scrollTo({ top: 0, behavior: "auto" });
  return bestReviews;
}

async function collectPageContext(options = {}) {
  const inlineReviews = options.deep ? await deepCollectReviews() : collectVisibleReviews();
  const headings = Array.from(document.querySelectorAll("h1, h2"))
    .map((node) => node.textContent.trim())
    .filter(Boolean)
    .slice(0, 8);

  const pageText = [
    document.title,
    textOf("h1"),
    metaContent("description"),
    metaContent("og:title"),
    metaContent("og:description"),
    headings.join("\n"),
    document.body ? document.body.innerText.slice(0, 5000) : ""
  ]
    .filter(Boolean)
    .join("\n");

  return {
    title: document.title || "",
    h1: textOf("h1"),
    meta_description: metaContent("description") || metaContent("og:description"),
    source_url: location.href,
    page_text: pageText,
    inline_reviews: inlineReviews
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "COLLECT_PAGE_CONTEXT") {
    collectPageContext({ deep: Boolean(message.deep) })
      .then(sendResponse)
      .catch((error) => sendResponse({ error: String(error) }));
  }
  return true;
});
