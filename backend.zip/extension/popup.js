const API_URL = "http://localhost:8765";

const statusEl = document.getElementById("status");
const objectNameEl = document.getElementById("objectName");
const analyzeButton = document.getElementById("analyzeButton");
const selectionButton = document.getElementById("selectionButton");
const openAppButton = document.getElementById("openAppButton");
const resultEl = document.getElementById("result");
const totalReviewsEl = document.getElementById("totalReviews");
const emotionEl = document.getElementById("emotion");
const sentimentEl = document.getElementById("sentiment");
const problemListEl = document.getElementById("problemList");
const strengthListEl = document.getElementById("strengthList");
const reportLinkEl = document.getElementById("reportLink");
const copyReportButton = document.getElementById("copyReportButton");
const sourceInfoEl = document.getElementById("sourceInfo");
const riskInfoEl = document.getElementById("riskInfo");

copyReportButton.disabled = true;

async function checkBackend() {
  try {
    const response = await fetch(`${API_URL}/health`);
    if (!response.ok) throw new Error("Backend недоступен");
    statusEl.textContent = "Backend: подключен";
  } catch (error) {
    statusEl.textContent = "Backend: не запущен";
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function splitReviewText(text) {
  return String(text || "")
    .split(/\n\s*\n|\n(?=.{25,})/g)
    .map((item) => item.replace(/\s+/g, " ").trim())
    .filter((item) => item.length >= 12)
    .slice(0, 300);
}

function setBusy(isBusy, label = "Анализировать страницу") {
  analyzeButton.disabled = isBusy;
  selectionButton.disabled = isBusy;
  analyzeButton.textContent = isBusy ? label : "Анализировать страницу";
  selectionButton.textContent = isBusy ? "Жду результат..." : "Выделенный текст";
}

function formatPercent(value) {
  return `${Math.round(Number(value || 0) * 100)}%`;
}

async function collectSelectionContext(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const selection = String(window.getSelection?.().toString() || "").trim();
      return {
        title: document.title || "",
        h1: document.querySelector("h1")?.textContent?.trim() || "",
        meta_description: document.querySelector('meta[name="description"]')?.content || "",
        source_url: location.href,
        selected_text: selection
      };
    }
  });

  const context = result.result || {};
  const selectedText = String(context.selected_text || "").trim();
  const selectedReviews = splitReviewText(selectedText).map((text) => ({
    source: "selected_text",
    text
  }));

  if (selectedReviews.length === 0) {
    throw new Error("Нет выделенного текста для анализа");
  }

  return {
    ...context,
    page_text: selectedText.slice(0, 5000),
    inline_reviews: selectedReviews
  };
}

async function collectYandexEdaContext(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async () => {
      const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      const normalize = (text) => (text || "").replace(/\s+/g, " ").trim();
      const clean = (text) =>
        normalize(text)
          .replace(/Читать целиком/gi, " ")
          .replace(/Ответ ресторана[\s\S]*$/i, " ")
          .replace(/\s+/g, " ")
          .trim();
      const extractReviews = () => {
        const bodyText = normalize(document.body ? document.body.innerText : "");
        const monthPattern = "января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря";
        const datePattern = `\\d{1,2}\\s+(?:${monthPattern})(?:\\s+20\\d{2})?`;
        const reviewPattern = new RegExp(
          `(?:^|\\s)([A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?)\\s+` +
            `(${datePattern}\\s*·\\s*(?:Я\\.Еда|Я\\.Карты|Яндекс\\.Еда|Яндекс\\.Карты))\\s+` +
            `([\\s\\S]*?)` +
            `(?=\\s+[A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?\\s+${datePattern}\\s*·\\s*(?:Я\\.Еда|Я\\.Карты|Яндекс\\.Еда|Яндекс\\.Карты)|$)`,
          "gi"
        );
        const reviews = [];
        const seen = new Set();
        let match;
        while ((match = reviewPattern.exec(bodyText)) && reviews.length < 300) {
          const text = clean(match[3] || "");
          if (text.length < 5 || text.length > 1000) continue;
          const fingerprint = text.toLowerCase().slice(0, 180);
          if (seen.has(fingerprint)) continue;
          seen.add(fingerprint);
          reviews.push({ source: "yandex_eda_modal", text });
        }
        return reviews;
      };
      const clickRating = () => {
        const controls = Array.from(document.querySelectorAll("button, a, [role='button'], [tabindex='0']"));
        const target = controls.find((element) => {
          const text = normalize(element.innerText || element.textContent || "");
          return /\d+[,.]\d\s*·\s*\d+\s+оцен/i.test(text) || /рейтинг\s+я\./i.test(text);
        });
        if (!target) return false;
        target.scrollIntoView({ block: "center", inline: "nearest" });
        target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
        if (typeof target.click === "function") target.click();
        return true;
      };
      const scrollModals = () => {
        const containers = Array.from(
          document.querySelectorAll("[role='dialog'], [aria-modal='true'], [class*='modal' i], [class*='popup' i], [class*='drawer' i], [class*='scroll' i], [class*='review' i]")
        ).filter((element) => element.scrollHeight > element.clientHeight + 80);
        for (const element of containers) {
          element.scrollTop = Math.min(element.scrollTop + Math.max(360, element.clientHeight * 0.85), element.scrollHeight);
        }
      };

      clickRating();
      await wait(1600);
      let bestReviews = extractReviews();
      let stagnant = 0;
      for (let i = 0; i < 14; i += 1) {
        scrollModals();
        await wait(450);
        const current = extractReviews();
        if (current.length > bestReviews.length) {
          bestReviews = current;
          stagnant = 0;
        } else {
          stagnant += 1;
        }
        if (bestReviews.length >= 300 || stagnant >= 4) break;
      }

      return {
        title: document.title || "",
        h1: document.querySelector("h1")?.textContent?.trim() || "",
        meta_description: document.querySelector('meta[name="description"]')?.content || "",
        source_url: location.href,
        page_text: document.body ? document.body.innerText.slice(0, 5000) : "",
        inline_reviews: bestReviews
      };
    }
  });
  return result.result;
}

async function collectTopHotelsContext(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const normalize = (text) => (text || "").replace(/\s+/g, " ").trim();
      const clean = (text) =>
        normalize(text)
          .replace(/ИНФОПОВОДЫ ОТЕЛЕЙ ТОПХОТЕЛС[\s\S]*$/i, " ")
          .replace(/РЕКЛАМА[\s\S]*$/i, " ")
          .replace(/\.\.\.$/, "")
          .replace(/\s+/g, " ")
          .trim();
      const bodyText = normalize(document.body ? document.body.innerText : "");
      const reviewPattern = /(?:^|\s)(\d[.,]\d{2})\s+\d\s*РАЗМЕЩЕНИЕ\s+\d\s*СЕРВИС\s+\d\s*ПИТАНИЕ\s+20\d{2}\s+[А-ЯЁ]+\s+([\s\S]*?)\s+(\d{2}\.\d{2}\.\d{4})\s+(?:Корректный отзыв|Мини оценка|\/ МИНИ ОЦЕНКА)/gi;
      const reviews = [];
      const seen = new Set();
      let match;

      while ((match = reviewPattern.exec(bodyText)) && reviews.length < 300) {
        const text = clean(match[2] || "");
        if (/МИНИ ОЦЕНКА/i.test(text)) continue;
        if (text.length < 40 || text.length > 1800) continue;
        const fingerprint = text.toLowerCase().slice(0, 220);
        if (seen.has(fingerprint)) continue;
        seen.add(fingerprint);
        const rating = Number(String(match[1] || "").replace(",", "."));
        reviews.push({
          source: "tophotels_visible_text",
          rating: Number.isFinite(rating) ? Math.round(rating) : null,
          text
        });
      }

      return {
        title: document.title || "",
        h1: document.querySelector("h1")?.textContent?.trim() || "",
        meta_description: document.querySelector('meta[name="description"]')?.content || "",
        source_url: location.href,
        page_text: bodyText.slice(0, 5000),
        inline_reviews: reviews
      };
    }
  });
  return result.result;
}

async function collectContext(tabId) {
  try {
    const context = await chrome.tabs.sendMessage(tabId, { type: "COLLECT_PAGE_CONTEXT", deep: true });
    const reviewCount = Array.isArray(context.inline_reviews) ? context.inline_reviews.length : 0;
    if (reviewCount === 0 && String(context.source_url || "").includes("eda.yandex.ru")) {
      const yandexEdaContext = await collectYandexEdaContext(tabId);
      if (Array.isArray(yandexEdaContext.inline_reviews) && yandexEdaContext.inline_reviews.length > 0) {
        return yandexEdaContext;
      }
    }
    if (reviewCount === 0 && String(context.source_url || "").includes("tophotels.ru")) {
      const topHotelsContext = await collectTopHotelsContext(tabId);
      if (Array.isArray(topHotelsContext.inline_reviews) && topHotelsContext.inline_reviews.length > 0) {
        return topHotelsContext;
      }
    }
    return context;
  } catch (error) {
    const [tabInfo] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (String(tabInfo?.url || "").includes("eda.yandex.ru")) {
      return await collectYandexEdaContext(tabId);
    }
    if (String(tabInfo?.url || "").includes("tophotels.ru")) {
      return await collectTopHotelsContext(tabId);
    }

    const [result] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const normalize = (text) => (text || "").replace(/\s+/g, " ").trim();
        const clean = (text) =>
          normalize(text)
            .replace(/Читать целиком/gi, " ")
            .replace(/Отзыв выбран компанией/gi, " ")
            .replace(/Отзыв подтвержд[её]н/gi, " ")
            .replace(/\d+\s+посещени[еяй]/gi, " ")
            .replace(/Полезно\?/gi, " ")
            .replace(/\s+/g, " ")
            .trim();
        const extract2gisReviews = () => {
          const bodyText = normalize(document.body ? document.body.innerText : "");
          if (!bodyText || !/2gis|2гис|отзывы|оценок/i.test(`${location.hostname} ${document.title} ${bodyText.slice(0, 1500)}`)) {
            return [];
          }
          const monthPattern = "января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря";
          const datePattern = `\\d{1,2}\\s+(?:${monthPattern})\\s+20\\d{2}`;
          const reviewPattern = new RegExp(
            `(?:^|\\s)([A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?)\\s+` +
              `(?:\\d+\\s+отзыв(?:ов|а)?\\s+)?` +
              `(${datePattern}(?:,\\s*(?:измен[её]н|официальный ответ))?)\\s+` +
              `([\\s\\S]*?)` +
              `(?=\\s+[A-ZА-ЯЁ][A-Za-zА-Яа-яЁё0-9 .,:()_\\-]{0,80}?\\s+(?:\\d+\\s+отзыв(?:ов|а)?\\s+)?${datePattern}|$)`,
            "gi"
          );
          const reviews = [];
          const seen = new Set();
          let match;
          while ((match = reviewPattern.exec(bodyText)) && reviews.length < 300) {
            if (/официальный ответ/i.test(match[2] || "")) continue;
            let text = clean(match[3] || "").replace(/(?:\s+\d+){1,4}$/g, "").trim();
            if (/официальный ответ/i.test(text) || text.length < 5 || text.length > 1000) continue;
            const fingerprint = text.toLowerCase().slice(0, 180);
            if (seen.has(fingerprint)) continue;
            seen.add(fingerprint);
            reviews.push({ source: "2gis_visible_text", text });
          }
          return reviews;
        };
        return {
          title: document.title || "",
          h1: document.querySelector("h1")?.textContent?.trim() || "",
          meta_description: document.querySelector('meta[name="description"]')?.content || "",
          source_url: location.href,
          page_text: document.body ? document.body.innerText.slice(0, 5000) : "",
          inline_reviews: extract2gisReviews()
        };
      }
    });
    return result.result;
  }
}

function renderResult(analysis) {
  resultEl.classList.remove("hidden");
  totalReviewsEl.textContent = analysis.summary.total_reviews;
  emotionEl.textContent = analysis.summary.dominant_emotion;
  sentimentEl.textContent = analysis.summary.dominant_sentiment;

  problemListEl.innerHTML = "";
  strengthListEl.innerHTML = "";
  sourceInfoEl.textContent = analysis.source ? analysis.source.message : "";
  const riskLevel = analysis.summary.risk_level || "нет данных";
  const riskScore = formatPercent(analysis.summary.risk_score);
  riskInfoEl.textContent = `Риск: ${riskLevel} · ${riskScore}. ${analysis.summary.next_step || ""}`.trim();

  const problems = analysis.problem_aspects.slice(0, 3);
  if (problems.length === 0) {
    const item = document.createElement("li");
    item.textContent = "Критичных проблем не найдено";
    problemListEl.appendChild(item);
  } else {
    for (const problem of problems) {
      const item = document.createElement("li");
      item.textContent = `${problem.aspect}: ${problem.negative_reviews} негативных отзыв. Доля: ${formatPercent(problem.share)}.`;
      problemListEl.appendChild(item);
    }
  }

  const strengths = (analysis.strength_aspects || []).slice(0, 3);
  if (strengths.length === 0) {
    const item = document.createElement("li");
    item.textContent = "Сильные стороны пока не выделены";
    strengthListEl.appendChild(item);
  } else {
    for (const strength of strengths) {
      const item = document.createElement("li");
      item.textContent = `${strength.aspect}: ${strength.positive_reviews} позитивных упоминаний.`;
      strengthListEl.appendChild(item);
    }
  }

  reportLinkEl.href = analysis.report_url;
  copyReportButton.disabled = !analysis.report_url;
}

async function sendForAnalysis(context, readyMessage) {
  try {
    const objectName = objectNameEl.value.trim();

    const reviewCount = Array.isArray(context.inline_reviews) ? context.inline_reviews.length : 0;
    statusEl.textContent = `Найдено отзывов: ${reviewCount}. Отправка на анализ`;
    const response = await fetch(`${API_URL}/api/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...context,
        object_name: objectName
      })
    });

    if (!response.ok) {
      throw new Error("Ошибка анализа");
    }

    const analysis = await response.json();
    if (!objectNameEl.value.trim()) {
      objectNameEl.value = analysis.object.name;
    }
    renderResult(analysis);
    statusEl.textContent = readyMessage;
  } catch (error) {
    statusEl.textContent = "Не удалось выполнить анализ";
  }
}

async function analyzePage() {
  setBusy(true, "Собираю отзывы...");
  statusEl.textContent = "Открываю и прокручиваю отзывы";

  try {
    const tab = await getActiveTab();
    const context = await collectContext(tab.id);
    await sendForAnalysis(context, "Анализ страницы готов");
  } catch (error) {
    statusEl.textContent = "Не удалось собрать отзывы со страницы";
  } finally {
    setBusy(false);
  }
}

async function analyzeSelection() {
  setBusy(true, "Готовлю выборку...");
  statusEl.textContent = "Читаю выделенный текст";

  try {
    const tab = await getActiveTab();
    const context = await collectSelectionContext(tab.id);
    await sendForAnalysis(context, "Анализ выделенного текста готов");
  } catch (error) {
    statusEl.textContent = "Выдели один или несколько отзывов на странице";
  } finally {
    setBusy(false);
  }
}

function openApp() {
  chrome.tabs.create({ url: `${API_URL}/` });
}

async function copyReportLink() {
  if (!reportLinkEl.href || reportLinkEl.href.endsWith("#")) {
    statusEl.textContent = "Сначала сформируй отчет";
    return;
  }

  try {
    await navigator.clipboard.writeText(reportLinkEl.href);
    statusEl.textContent = "Ссылка на отчет скопирована";
  } catch (error) {
    statusEl.textContent = "Не удалось скопировать ссылку";
  }
}

checkBackend();
analyzeButton.addEventListener("click", analyzePage);
selectionButton.addEventListener("click", analyzeSelection);
openAppButton.addEventListener("click", openApp);
copyReportButton.addEventListener("click", copyReportLink);
