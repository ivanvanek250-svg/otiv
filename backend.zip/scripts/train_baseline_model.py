from __future__ import annotations

import json
import math
import random
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT / "backend") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "backend"))

from analyzer import analyze_reviews  # noqa: E402


ANALYSES_ROOT = PROJECT_ROOT / "data" / "analyses"
DEMO_REVIEWS_PATH = PROJECT_ROOT / "backend" / "demo_reviews.json"
MODEL_ROOT = PROJECT_ROOT / "models"
MODEL_PATH = MODEL_ROOT / "baseline_review_model.json"
RANDOM_SEED = 42


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower().replace("ё", "е")).strip()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zа-я0-9]{2,}", normalize(text))


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def collect_from_analyses() -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for path in sorted(ANALYSES_ROOT.glob("*.json")):
        try:
            analysis = load_json(path)
        except json.JSONDecodeError:
            continue
        for review in analysis.get("reviews", []):
            text = str(review.get("text") or "").strip()
            sentiment = str(review.get("sentiment") or "").strip()
            emotion = str(review.get("emotion", {}).get("label") or "").strip()
            aspects = [aspect.get("label") for aspect in review.get("aspects", []) if aspect.get("label")]
            if len(text) >= 12 and sentiment and emotion and aspects:
                items.append(
                    {
                        "text": text,
                        "sentiment": sentiment,
                        "emotion": emotion,
                        "aspect": aspects[0],
                        "source": review.get("source", "analysis"),
                    }
                )
    return items


def collect_from_demo() -> list[dict[str, Any]]:
    if not DEMO_REVIEWS_PATH.exists():
        return []
    demo_reviews = load_json(DEMO_REVIEWS_PATH)
    analysis = analyze_reviews({"object_name": "demo", "inline_reviews": demo_reviews})
    return [
        {
            "text": review["text"],
            "sentiment": review["sentiment"],
            "emotion": review["emotion"]["label"],
            "aspect": review["aspects"][0]["label"],
            "source": review.get("source", "demo"),
        }
        for review in analysis.get("reviews", [])
        if review.get("aspects")
    ]


def deduplicate(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for item in items:
        fingerprint = normalize(item["text"])[:240]
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        result.append(item)
    return result


class NaiveBayes:
    def __init__(self) -> None:
        self.label_counts: Counter[str] = Counter()
        self.word_counts: dict[str, Counter[str]] = defaultdict(Counter)
        self.total_words: Counter[str] = Counter()
        self.vocabulary: set[str] = set()

    def fit(self, items: list[dict[str, Any]], label_key: str) -> None:
        for item in items:
            label = item[label_key]
            tokens = tokenize(item["text"])
            self.label_counts[label] += 1
            self.word_counts[label].update(tokens)
            self.total_words[label] += len(tokens)
            self.vocabulary.update(tokens)

    def predict(self, text: str) -> str:
        tokens = tokenize(text)
        labels = list(self.label_counts)
        if not labels:
            return ""

        total_docs = sum(self.label_counts.values())
        vocab_size = max(len(self.vocabulary), 1)
        scores: dict[str, float] = {}
        for label in labels:
            score = math.log(self.label_counts[label] / total_docs)
            denominator = self.total_words[label] + vocab_size
            for token in tokens:
                score += math.log((self.word_counts[label][token] + 1) / denominator)
            scores[label] = score
        return max(scores.items(), key=lambda item: item[1])[0]

    def to_dict(self) -> dict[str, Any]:
        return {
            "label_counts": dict(self.label_counts),
            "word_counts": {label: dict(counter) for label, counter in self.word_counts.items()},
            "total_words": dict(self.total_words),
            "vocabulary": sorted(self.vocabulary),
        }


def train_and_evaluate(items: list[dict[str, Any]], label_key: str) -> dict[str, Any]:
    shuffled = items[:]
    random.Random(RANDOM_SEED).shuffle(shuffled)
    split = max(1, int(len(shuffled) * 0.8))
    train_items = shuffled[:split]
    test_items = shuffled[split:] or shuffled[:]

    model = NaiveBayes()
    model.fit(train_items, label_key)
    correct = sum(1 for item in test_items if model.predict(item["text"]) == item[label_key])
    accuracy = correct / max(len(test_items), 1)
    return {
        "model": model.to_dict(),
        "train_size": len(train_items),
        "test_size": len(test_items),
        "accuracy": round(accuracy, 3),
        "labels": sorted(model.label_counts),
    }


def main() -> None:
    items = deduplicate(collect_from_analyses() + collect_from_demo())
    if len(items) < 8:
        raise SystemExit("Недостаточно размеченных отзывов для обучения. Сначала собери больше отчетов.")

    trained = {
        "model_type": "multinomial_naive_bayes",
        "language": "ru",
        "tokenizer": "regex_words_v1",
        "dataset_size": len(items),
        "sentiment": train_and_evaluate(items, "sentiment"),
        "emotion": train_and_evaluate(items, "emotion"),
        "aspect": train_and_evaluate(items, "aspect"),
    }

    MODEL_ROOT.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.write_text(json.dumps(trained, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Модель сохранена: {MODEL_PATH}")
    print(f"Размер датасета: {trained['dataset_size']}")
    print(f"Тональность accuracy: {trained['sentiment']['accuracy']}")
    print(f"Эмоции accuracy: {trained['emotion']['accuracy']}")
    print(f"Аспекты accuracy: {trained['aspect']['accuracy']}")


if __name__ == "__main__":
    main()
