from __future__ import annotations

import json
import mimetypes
import os
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from analyzer import analyze_reviews


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = PROJECT_ROOT / "web"
DATA_ROOT = PROJECT_ROOT / "data"
ANALYSES_ROOT = DATA_ROOT / "analyses"
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8765"))
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")


ANALYSES_ROOT.mkdir(parents=True, exist_ok=True)


def safe_print(message: str) -> None:
    try:
        print(message, flush=True)
    except OSError:
        pass


def json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type")
    handler.end_headers()
    handler.wfile.write(body)


def read_json_body(handler: BaseHTTPRequestHandler) -> dict:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length == 0:
        return {}
    raw = handler.rfile.read(length).decode("utf-8")
    return json.loads(raw)


def save_analysis(analysis: dict) -> str:
    analysis_id = uuid.uuid4().hex[:12]
    analysis["id"] = analysis_id
    (ANALYSES_ROOT / f"{analysis_id}.json").write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return analysis_id


def load_analysis(analysis_id: str) -> dict | None:
    path = ANALYSES_ROOT / f"{analysis_id}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def request_base_url(handler: BaseHTTPRequestHandler) -> str:
    if PUBLIC_BASE_URL:
        return PUBLIC_BASE_URL
    forwarded_proto = handler.headers.get("X-Forwarded-Proto", "").split(",")[0].strip()
    proto = forwarded_proto or ("https" if handler.headers.get("X-Forwarded-Ssl") == "on" else "http")
    host = handler.headers.get("X-Forwarded-Host") or handler.headers.get("Host") or f"localhost:{PORT}"
    return f"{proto}://{host}".rstrip("/")


class ReviewAnalyzerHandler(BaseHTTPRequestHandler):
    server_version = "ReviewAnalyzer/0.1"

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/health":
            json_response(self, 200, {"status": "ok", "service": "review-analyzer"})
            return

        if path.startswith("/api/analysis/"):
            analysis_id = path.rsplit("/", 1)[-1]
            analysis = load_analysis(analysis_id)
            if analysis is None:
                json_response(self, 404, {"error": "analysis_not_found"})
                return
            json_response(self, 200, analysis)
            return

        if path.startswith("/report/"):
            self.serve_static(WEB_ROOT / "report.html")
            return

        if path == "/":
            self.serve_static(WEB_ROOT / "index.html")
            return

        if path == "/report":
            self.serve_static(WEB_ROOT / "report.html")
            return

        static_path = (WEB_ROOT / path.lstrip("/")).resolve()
        if WEB_ROOT.resolve() in static_path.parents and static_path.exists():
            self.serve_static(static_path)
            return

        json_response(self, 404, {"error": "not_found"})

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/analyze":
            json_response(self, 404, {"error": "not_found"})
            return

        try:
            payload = read_json_body(self)
            analysis = analyze_reviews(payload)
            analysis_id = save_analysis(analysis)
            analysis["report_url"] = f"{request_base_url(self)}/report/{analysis_id}"
            json_response(self, 200, analysis)
        except json.JSONDecodeError:
            json_response(self, 400, {"error": "invalid_json"})
        except Exception as error:  # pragma: no cover - API safety net
            json_response(self, 500, {"error": "internal_error", "detail": str(error)})

    def serve_static(self, path: Path) -> None:
        if not path.exists():
            json_response(self, 404, {"error": "static_not_found"})
            return
        body = path.read_bytes()
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if path.suffix in {".html", ".css", ".js"}:
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args) -> None:
        safe_print("%s - %s" % (self.address_string(), format % args))


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), ReviewAnalyzerHandler)
    safe_print(f"Review analyzer backend: http://{HOST}:{PORT}")
    safe_print("Press Ctrl+C to stop")
    server.serve_forever()


if __name__ == "__main__":
    main()
