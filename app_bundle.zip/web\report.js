const state = {
  analysis: null,
  filteredReviews: [],
  activeTab: "overview"
};

const controls = {
  search: document.getElementById("searchInput"),
  sentiment: document.getElementById("sentimentFilter"),
  emotion: document.getElementById("emotionFilter"),
  aspect: document.getElementById("aspectFilter"),
  source: document.getElementById("sourceFilter"),
  rating: document.getElementById("ratingFilter"),
  sort: document.getElementById("sortSelect"),
  reset: document.getElementById("resetFiltersButton"),
  exportCsv: document.getElementById("exportCsvButton"),
  exportJson: document.getElementById("exportJsonButton"),
  copyReport: document.getElementById("copyReportButton"),
  copySummary: document.getElementById("copySummaryButton"),
  printReport: document.getElementById("printReportButton"),
  quickActions: Array.from(document.querySelectorAll("[data-action]")),
  tabs: Array.from(document.querySelectorAll("[data-tab]"))
};

function getAnalysisId() {
  const parts = window.location.pathname.split("/").filter(Boolean);
  return parts[0] === "report" ? parts[1] : null;
}

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function createTextElement(tagName, text, className = "") {
  const element = document.createElement(tagName);
  if (className) element.className = className;
  element.textContent = text;
  return element;
}

function reviewAspects(review) {
  return (review.aspects || []).map((aspect) => aspect.label).filter(Boolean);
}

function formatSource(source) {
  const labels = {
    "2gis_visible_text": "2ГИС",
    "yandex_eda_modal": "Яндекс Еда",
    "tophotels_visible_text": "TopHotels",
    "avito_visible_text": "Avito",
    "otzovik_visible": "Отзовик",
    "irecommend_visible": "IRecommend",
    "visible_page": "Страница",
    "visible_page_text": "Текст страницы",
    "selected_text": "Выделенный текст",
    "manual_input": "Ручной ввод"
  };
  return labels[source] || String(source || "-").replace(/_/g, " ");
}

function sentimentClass(sentiment) {
  if (sentiment === "негатив") return "negative";
  if (sentiment === "позитив") return "positive";
  return "neutral";
}

function emotionClass(emotion) {
  if (emotion === "радость") return "joy";
  if (emotion === "гнев") return "anger";
  if (emotion === "разочарование") return "sadness";
  if (emotion === "тревога") return "anxiety";
  return "neutral";
}

function ratingLabel(rating) {
  return typeof rating === "number" ? `${rating}/5` : "без оценки";
}

function createMetaItem(label, value) {
  const item = document.createElement("span");
  item.className = "review-meta-item";
  item.append(createTextElement("small", label), createTextElement("strong", value));
  return item;
}

function createActionButton(label, onClick, className = "mini-action") {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.textContent = label;
  button.addEventListener("click", onClick);
  return button;
}

function renderBars(containerId, data) {
  const container = document.getElementById(containerId);
  container.innerHTML = "";
  const entries = Object.entries(data || {});
  const max = Math.max(...entries.map(([, value]) => value), 1);

  if (entries.length === 0) {
    container.textContent = "Нет данных";
    return;
  }

  for (const [label, value] of entries) {
    const row = document.createElement("div");
    row.className = "bar-row";
    const labelEl = createTextElement("span", label);
    const track = document.createElement("div");
    track.className = "track";
    const fill = document.createElement("div");
    fill.className = "fill";
    fill.style.width = `${(value / max) * 100}%`;
    track.appendChild(fill);
    const valueEl = createTextElement("strong", value);
    row.append(labelEl, track, valueEl);
    container.appendChild(row);
  }
}

function renderProblems(problems) {
  const container = document.getElementById("problems");
  container.innerHTML = "";

  if (!problems || problems.length === 0) {
    container.className = "aspect-card-list empty-aspect-list";
    container.textContent = "Выраженных проблемных аспектов не найдено.";
    return;
  }

  container.className = "aspect-card-list";
  for (const problem of problems) {
    const element = document.createElement("article");
    element.className = "aspect-card aspect-card-negative";

    const header = document.createElement("div");
    header.className = "aspect-card-head";
    header.appendChild(createTextElement("h3", problem.aspect));
    header.appendChild(createTextElement("span", `${problem.negative_reviews} негатив`, "aspect-count danger"));
    element.appendChild(header);

    if (problem.explanation) {
      element.appendChild(createTextElement("p", problem.explanation, "aspect-card-text"));
    }

    const examples = document.createElement("div");
    examples.className = "aspect-examples";
    for (const example of (problem.examples || []).slice(0, 2)) {
      examples.appendChild(createTextElement("blockquote", example));
    }
    if (examples.childElementCount) element.appendChild(examples);

    const footer = document.createElement("div");
    footer.className = "aspect-card-foot";
    footer.appendChild(createTextElement("p", problem.recommendation, "aspect-recommendation"));
    footer.appendChild(createActionButton("Показать отзывы", () => filterToAspect(problem.aspect, "негатив")));
    footer.appendChild(createActionButton("Копировать", () => copyText(problem.recommendation, "Скопировано")));
    element.appendChild(footer);

    container.appendChild(element);
  }
}

function renderStrengths(strengths) {
  const container = document.getElementById("strengths");
  container.innerHTML = "";

  if (!strengths || strengths.length === 0) {
    container.className = "aspect-card-list empty-aspect-list";
    container.textContent = "Сильные стороны пока не выражены явно.";
    return;
  }

  container.className = "aspect-card-list";
  for (const strength of strengths) {
    const element = document.createElement("article");
    element.className = "aspect-card aspect-card-positive";

    const header = document.createElement("div");
    header.className = "aspect-card-head";
    header.appendChild(createTextElement("h3", strength.aspect));
    header.appendChild(createTextElement("span", `${strength.positive_reviews} позитив`, "aspect-count success"));
    element.appendChild(header);

    if (strength.explanation) {
      element.appendChild(createTextElement("p", strength.explanation, "aspect-card-text"));
    }

    const examples = document.createElement("div");
    examples.className = "aspect-examples";
    for (const example of (strength.examples || []).slice(0, 2)) {
      examples.appendChild(createTextElement("blockquote", example));
    }
    if (examples.childElementCount) element.appendChild(examples);

    const footer = document.createElement("div");
    footer.className = "aspect-card-foot";
    footer.appendChild(createTextElement("p", strength.recommendation, "aspect-recommendation"));
    footer.appendChild(createActionButton("Показать отзывы", () => filterToAspect(strength.aspect, "позитив")));
    footer.appendChild(createActionButton("Копировать", () => copyText(strength.recommendation, "Скопировано")));
    element.appendChild(footer);

    container.appendChild(element);
  }
}

function renderAspectInsights(insights) {
  const container = document.getElementById("aspectInsights");
  container.innerHTML = "";

  if (!insights || insights.length === 0) {
    container.className = "aspect-radar-list empty-aspect-list";
    container.textContent = "Недостаточно данных для баланса аспектов.";
    return;
  }

  const statusClass = {
    "зона риска": "risk",
    "сильная сторона": "good",
    "поляризует": "mixed",
    "наблюдать": "watch"
  };

  container.className = "aspect-radar-list";
  for (const insight of insights) {
    const element = document.createElement("article");
    element.className = `aspect-radar-card ${statusClass[insight.status] || "watch"}`;

    const head = document.createElement("div");
    head.className = "aspect-radar-head";
    head.appendChild(createTextElement("strong", insight.aspect));
    head.appendChild(createTextElement("span", insight.status, `aspect-status ${statusClass[insight.status] || "watch"}`));
    element.appendChild(head);

    const scoreRow = document.createElement("div");
    scoreRow.className = "aspect-score-row";
    scoreRow.appendChild(createTextElement("span", `+${insight.positive}`, "score-positive"));
    scoreRow.appendChild(createTextElement("span", `-${insight.negative}`, "score-negative"));
    scoreRow.appendChild(createTextElement("span", `0${insight.neutral}`, "score-neutral"));
    scoreRow.appendChild(createTextElement("span", `${Math.round((insight.share || 0) * 100)}% выборки`, "score-share"));
    element.appendChild(scoreRow);

    const balance = document.createElement("div");
    balance.className = "balance";
    const track = document.createElement("div");
    track.className = "balance-track";
    const negative = Math.max(insight.negative || 0, 0.01);
    const positive = Math.max(insight.positive || 0, 0.01);
    const neutral = Math.max(insight.neutral || 0, 0.01);
    track.style.setProperty("--negative", `${negative}fr`);
    track.style.setProperty("--positive", `${positive}fr`);
    track.style.setProperty("--neutral", `${neutral}fr`);
    track.append(document.createElement("span"), document.createElement("span"), document.createElement("span"));
    balance.appendChild(track);
    if (insight.explanation) {
      balance.appendChild(createTextElement("small", insight.explanation, "insight-explanation"));
    }
    element.appendChild(balance);

    const actions = document.createElement("div");
    actions.className = "aspect-radar-actions";
    actions.appendChild(createActionButton("Все отзывы", () => filterToAspect(insight.aspect)));
    if (insight.negative > 0) {
      actions.appendChild(createActionButton("Только негатив", () => filterToAspect(insight.aspect, "негатив")));
    }
    element.appendChild(actions);

    container.appendChild(element);
  }
}

function renderRiskIndex(riskIndex) {
  const container = document.getElementById("riskIndex");
  if (!container) return;
  container.innerHTML = "";

  if (!riskIndex) {
    container.textContent = "Недостаточно данных для расчета индекса.";
    return;
  }

  const score = Math.max(0, Math.min(Number(riskIndex.score || 0), 100));
  const hero = document.createElement("div");
  hero.className = "risk-hero";

  const scoreBox = document.createElement("div");
  scoreBox.className = "risk-score-box";
  scoreBox.appendChild(createTextElement("span", "индекс"));
  scoreBox.appendChild(createTextElement("strong", String(score)));
  scoreBox.appendChild(createTextElement("small", "из 100"));

  const info = document.createElement("div");
  info.className = "risk-index-copy";
  info.appendChild(createTextElement("span", riskIndex.level || "нет данных", `risk-level-pill risk-${riskIndex.level || "none"}`));
  info.appendChild(createTextElement("p", riskIndex.interpretation || ""));

  hero.append(scoreBox, info);

  const meter = document.createElement("div");
  meter.className = "risk-meter";
  meter.style.setProperty("--score", `${score}%`);
  meter.appendChild(document.createElement("span"));

  const drivers = document.createElement("div");
  drivers.className = "risk-drivers";
  for (const driver of riskIndex.drivers || []) {
    drivers.appendChild(createTextElement("span", driver));
  }

  const actions = document.createElement("div");
  actions.className = "risk-mini-actions";
  actions.appendChild(createActionButton("Открыть негатив", showNegativeReviews));
  actions.appendChild(createActionButton("К проблемным аспектам", () => scrollToSection("problems")));

  container.append(hero, meter, drivers, actions);
}

function renderSourceComparison(sources) {
  const container = document.getElementById("sourceComparison");
  if (!container) return;
  container.innerHTML = "";

  if (!sources || sources.length === 0) {
    container.textContent = "Недостаточно данных для сравнения источников.";
    return;
  }

  for (const source of sources.slice(0, 5)) {
    const row = document.createElement("article");
    row.className = "source-row";

    const head = document.createElement("div");
    head.className = "source-row-head";
    head.appendChild(createTextElement("strong", source.label || formatSource(source.source)));
    head.appendChild(createTextElement("span", `${source.total} отзывов`));

    const mix = document.createElement("div");
    mix.className = "sentiment-mix";
    const negative = Math.max(source.negative || 0, 0.01);
    const positive = Math.max(source.positive || 0, 0.01);
    const neutral = Math.max(source.neutral || 0, 0.01);
    mix.style.setProperty("--negative", `${negative}fr`);
    mix.style.setProperty("--positive", `${positive}fr`);
    mix.style.setProperty("--neutral", `${neutral}fr`);
    mix.append(document.createElement("span"), document.createElement("span"), document.createElement("span"));

    const meta = document.createElement("p");
    meta.textContent = `негатив ${source.negative}, позитив ${source.positive}, аспект: ${source.top_aspect || "-"}`;

    row.append(head, mix, meta);
    container.appendChild(row);
  }
}

function renderAspectMatrix(rows) {
  const container = document.getElementById("aspectMatrix");
  if (!container) return;
  container.innerHTML = "";

  if (!rows || rows.length === 0) {
    container.textContent = "Аспекты не выделены.";
    return;
  }

  const table = document.createElement("div");
  table.className = "matrix-table";

  const header = document.createElement("div");
  header.className = "matrix-row matrix-header";
  for (const label of ["Аспект", "+", "-", "0", "Статус"]) {
    header.appendChild(createTextElement("span", label));
  }
  table.appendChild(header);

  for (const row of rows.slice(0, 8)) {
    const item = document.createElement("div");
    item.className = `matrix-row matrix-${row.status === "риск" ? "risk" : row.status === "сильная сторона" ? "good" : "watch"}`;
    item.appendChild(createTextElement("strong", row.aspect));
    item.appendChild(createTextElement("span", row.positive ?? 0));
    item.appendChild(createTextElement("span", row.negative ?? 0));
    item.appendChild(createTextElement("span", row.neutral ?? 0));
    item.appendChild(createTextElement("span", row.status || "наблюдать", "matrix-status"));
    table.appendChild(item);
  }

  container.appendChild(table);
}

function addOption(select, value, label) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = label;
  select.appendChild(option);
}

function fillSelect(select, values, allLabel) {
  select.innerHTML = "";
  addOption(select, "", allLabel);
  for (const value of values) {
    addOption(select, value, value);
  }
}

function uniqueSorted(values) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b, "ru"));
}

function populateFilters(analysis) {
  const reviews = analysis.reviews || [];
  fillSelect(controls.sentiment, uniqueSorted(reviews.map((review) => review.sentiment)), "Любая");
  fillSelect(controls.emotion, uniqueSorted(reviews.map((review) => review.emotion?.label)), "Любая");
  fillSelect(controls.aspect, uniqueSorted(reviews.flatMap(reviewAspects)), "Все аспекты");
  controls.source.innerHTML = "";
  addOption(controls.source, "", "Все источники");
  for (const source of uniqueSorted(reviews.map((review) => review.source))) {
    addOption(controls.source, source, formatSource(source));
  }
}

function getFilters() {
  return {
    query: controls.search.value.trim().toLowerCase(),
    sentiment: controls.sentiment.value,
    emotion: controls.emotion.value,
    aspect: controls.aspect.value,
    source: controls.source.value,
    rating: Number(controls.rating.value || 0),
    sort: controls.sort.value
  };
}

function matchesFilters(review, filters) {
  const searchable = [
    review.text,
    formatSource(review.source),
    review.source,
    review.sentiment,
    review.emotion?.label,
    ...reviewAspects(review)
  ].join(" ").toLowerCase();

  if (filters.query && !searchable.includes(filters.query)) return false;
  if (filters.sentiment && review.sentiment !== filters.sentiment) return false;
  if (filters.emotion && review.emotion?.label !== filters.emotion) return false;
  if (filters.aspect && !reviewAspects(review).includes(filters.aspect)) return false;
  if (filters.source && review.source !== filters.source) return false;
  if (filters.rating && !(Number(review.rating || 0) >= filters.rating)) return false;
  return true;
}

function sortReviews(reviews, sortMode) {
  const copy = [...reviews];
  const sentimentRank = { негатив: 0, нейтрально: 1, позитив: 2 };

  if (sortMode === "ratingAsc") {
    return copy.sort((a, b) => Number(a.rating ?? 99) - Number(b.rating ?? 99));
  }
  if (sortMode === "ratingDesc") {
    return copy.sort((a, b) => Number(b.rating ?? -1) - Number(a.rating ?? -1));
  }
  if (sortMode === "source") {
    return copy.sort((a, b) => String(a.source).localeCompare(String(b.source), "ru"));
  }

  return copy.sort((a, b) => {
    const sentimentDelta = (sentimentRank[a.sentiment] ?? 1) - (sentimentRank[b.sentiment] ?? 1);
    if (sentimentDelta !== 0) return sentimentDelta;
    return Number(a.rating ?? 99) - Number(b.rating ?? 99);
  });
}

function renderFilterSummary(reviews) {
  const ratings = reviews.map((review) => review.rating).filter((rating) => typeof rating === "number");
  const average = ratings.length ? (ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length).toFixed(2) : "-";
  setText("filteredReviews", reviews.length);
  setText("filteredNegative", reviews.filter((review) => review.sentiment === "негатив").length);
  setText("filteredPositive", reviews.filter((review) => review.sentiment === "позитив").length);
  setText("filteredAverage", average);
  setText("reviewCounter", `Показано ${reviews.length} из ${state.analysis?.reviews?.length || 0}`);
}

function renderActiveFilters(filters) {
  const container = document.getElementById("activeFilters");
  container.innerHTML = "";
  const chips = [];
  if (filters.query) chips.push(`поиск: ${filters.query}`);
  if (filters.sentiment) chips.push(`тональность: ${filters.sentiment}`);
  if (filters.emotion) chips.push(`эмоция: ${filters.emotion}`);
  if (filters.aspect) chips.push(`аспект: ${filters.aspect}`);
  if (filters.source) chips.push(`источник: ${formatSource(filters.source)}`);
  if (filters.rating) chips.push(`оценка от ${filters.rating}`);

  if (chips.length === 0) {
    container.appendChild(createTextElement("span", "без фильтров", "chip"));
    return;
  }

  for (const chip of chips) {
    container.appendChild(createTextElement("span", chip, "chip"));
  }
}

function renderReviews(reviews) {
  const container = document.getElementById("reviewsList");
  container.innerHTML = "";

  if (reviews.length === 0) {
    container.appendChild(createTextElement("div", "По этим фильтрам отзывов нет.", "empty-state"));
    return;
  }

  for (const review of reviews) {
    const card = document.createElement("article");
    card.className = `review-card is-${sentimentClass(review.sentiment)}`;

    const header = document.createElement("div");
    header.className = "review-card-head";
    const title = document.createElement("div");
    title.className = "review-title";
    title.appendChild(createTextElement("span", `#${review.id || ""}`, "review-index"));
    title.appendChild(createTextElement("strong", formatSource(review.source)));
    header.appendChild(title);

    const signal = document.createElement("div");
    signal.className = "emotion-cell";
    signal.appendChild(createTextElement("span", review.emotion?.label || "-", `emotion-pill ${emotionClass(review.emotion?.label)}`));
    signal.appendChild(createTextElement("span", review.sentiment || "нейтрально", `sentiment-pill ${sentimentClass(review.sentiment)}`));
    header.appendChild(signal);
    card.appendChild(header);

    card.appendChild(createTextElement("p", review.text || "", "review-text"));

    const footer = document.createElement("div");
    footer.className = "review-card-foot";
    footer.appendChild(createMetaItem("оценка", ratingLabel(review.rating)));
    footer.appendChild(createMetaItem("аспектов", String(reviewAspects(review).length || 0)));

    const aspectCell = document.createElement("div");
    aspectCell.className = "review-aspects";
    const aspects = reviewAspects(review);
    if (aspects.length) {
      for (const label of aspects) {
        aspectCell.appendChild(createTextElement("span", label, "badge"));
      }
    } else {
      aspectCell.appendChild(createTextElement("span", "аспект не выделен", "badge muted-badge"));
    }
    footer.appendChild(aspectCell);

    card.append(footer);
    container.appendChild(card);
  }
}

function setActiveTab(tabName) {
  const nextTab = tabName === "reviews" ? "reviews" : "overview";
  state.activeTab = nextTab;
  for (const button of controls.tabs) {
    const isActive = button.dataset.tab === nextTab;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-selected", String(isActive));
  }
  document.getElementById("overviewTab")?.classList.toggle("active", nextTab === "overview");
  document.getElementById("reviewsTab")?.classList.toggle("active", nextTab === "reviews");
}

function syncReportTabFromHash() {
  setActiveTab(window.location.hash === "#reviews" ? "reviews" : "overview");
}

function applyFilters() {
  if (!state.analysis) return;
  const filters = getFilters();
  const filtered = sortReviews(
    (state.analysis.reviews || []).filter((review) => matchesFilters(review, filters)),
    filters.sort
  );
  state.filteredReviews = filtered;
  renderFilterSummary(filtered);
  renderActiveFilters(filters);
  renderReviews(filtered);
}

function resetFilters() {
  controls.search.value = "";
  controls.sentiment.value = "";
  controls.emotion.value = "";
  controls.aspect.value = "";
  controls.source.value = "";
  controls.rating.value = "";
  controls.sort.value = "risk";
  applyFilters();
}

function scrollToSection(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function openReviewsTab() {
  setActiveTab("reviews");
  window.history.replaceState(null, "", "#reviews");
  scrollToSection("reviewsTab");
}

function showNegativeReviews() {
  openReviewsTab();
  controls.sentiment.value = "негатив";
  controls.sort.value = "risk";
  applyFilters();
}

function filterToAspect(aspect, sentiment = "") {
  openReviewsTab();
  controls.aspect.value = aspect;
  if (sentiment) controls.sentiment.value = sentiment;
  controls.sort.value = "risk";
  applyFilters();
}

async function copyText(text, doneLabel = "Готово") {
  try {
    await navigator.clipboard.writeText(text || "");
    return doneLabel;
  } catch (error) {
    return "Ошибка";
  }
}

function csvEscape(value) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

function exportFilteredCsv() {
  const rows = [
    ["Источник", "Оценка", "Отзыв", "Эмоция", "Тональность", "Аспекты"],
    ...state.filteredReviews.map((review) => [
      formatSource(review.source),
      review.rating ?? "",
      review.text,
      review.emotion?.label || "",
      review.sentiment || "",
      reviewAspects(review).join("; ")
    ])
  ];
  const csv = rows.map((row) => row.map(csvEscape).join(";")).join("\n");
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `reviews-report-${getAnalysisId() || "export"}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function exportJson() {
  if (!state.analysis) return;
  const blob = new Blob([JSON.stringify(state.analysis, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `reviews-report-${getAnalysisId() || "export"}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

async function copySummary() {
  if (!state.analysis) return;
  const summary = state.analysis.summary || {};
  const risk = state.analysis.risk_index || {};
  const text = [
    state.analysis.object?.name || "Отчет анализа отзывов",
    summary.overall_review || "",
    summary.executive_summary || "",
    risk.interpretation || "",
    summary.next_step ? `Следующее действие: ${summary.next_step}` : ""
  ].filter(Boolean).join("\n\n");
  const label = await copyText(text, "Скопировано");
  controls.copySummary.textContent = label;
  setTimeout(() => {
    controls.copySummary.textContent = "Копировать вывод";
  }, 1300);
}

async function copyReportLink() {
  try {
    await navigator.clipboard.writeText(window.location.href);
    controls.copyReport.textContent = "Готово";
    setTimeout(() => {
      controls.copyReport.textContent = "Ссылка";
    }, 1200);
  } catch (error) {
    controls.copyReport.textContent = "Ошибка";
  }
}

async function loadReport() {
  const id = getAnalysisId();
  if (!id) {
    setText("objectMeta", "Открой отчет из расширения после анализа страницы.");
    return;
  }

  const response = await fetch(`/api/analysis/${id}`);
  if (!response.ok) {
    setText("objectMeta", "Отчет не найден.");
    return;
  }

  const analysis = await response.json();
  state.analysis = analysis;

  setText("objectName", analysis.object.name);
  setText(
    "objectMeta",
    `${analysis.object.type} · уверенность анализа ${Math.round(analysis.summary.confidence * 100)}%`
  );
  setText("sourceInfo", analysis.source ? analysis.source.message : "");
  setText("totalReviews", analysis.summary.total_reviews);
  setText("averageRating", analysis.summary.average_rating ?? "-");
  setText("dominantEmotion", analysis.summary.dominant_emotion);
  setText("dominantSentiment", analysis.summary.dominant_sentiment);
  setText("riskLevel", analysis.summary.risk_level || "-");
  setText("overallReview", analysis.summary.overall_review || "");
  setText("executiveSummary", analysis.summary.executive_summary || "");
  setText("nextStep", analysis.summary.next_step || "");
  renderBars("emotionBars", analysis.distributions.emotions);
  renderBars("aspectBars", analysis.distributions.aspects);
  renderStrengths(analysis.strength_aspects);
  renderProblems(analysis.problem_aspects);
  renderAspectInsights(analysis.aspect_insights);
  renderRiskIndex(analysis.risk_index);
  renderSourceComparison(analysis.source_comparison);
  renderAspectMatrix(analysis.aspect_sentiment_matrix);
  populateFilters(analysis);
  applyFilters();
  syncReportTabFromHash();
}

for (const control of [
  controls.search,
  controls.sentiment,
  controls.emotion,
  controls.aspect,
  controls.source,
  controls.rating,
  controls.sort
]) {
  control.addEventListener("input", applyFilters);
  control.addEventListener("change", applyFilters);
}

controls.reset.addEventListener("click", resetFilters);
controls.exportCsv.addEventListener("click", exportFilteredCsv);
controls.exportJson.addEventListener("click", exportJson);
controls.copyReport.addEventListener("click", copyReportLink);
controls.copySummary.addEventListener("click", copySummary);
controls.printReport.addEventListener("click", () => window.print());
for (const button of controls.quickActions) {
  button.addEventListener("click", () => {
    if (button.dataset.action === "focus-risk") scrollToSection("riskIndex");
    if (button.dataset.action === "show-negative") showNegativeReviews();
  });
}
for (const button of controls.tabs) {
  button.addEventListener("click", () => {
    setActiveTab(button.dataset.tab);
    window.history.replaceState(null, "", state.activeTab === "reviews" ? "#reviews" : "#overview");
  });
}
window.addEventListener("hashchange", syncReportTabFromHash);

loadReport();
