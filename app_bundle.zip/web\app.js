const API_URL = "";

const backendStatus = document.getElementById("backendStatus");
const analysisForm = document.getElementById("analysisForm");
const objectNameEl = document.getElementById("objectName");
const sourceUrlEl = document.getElementById("sourceUrl");
const reviewLimitEl = document.getElementById("reviewLimit");
const reviewsTextEl = document.getElementById("reviewsText");
const analyzeButton = document.getElementById("analyzeButton");
const sampleButton = document.getElementById("sampleButton");
const clearButton = document.getElementById("clearButton");
const resultTitle = document.getElementById("resultTitle");
const resultText = document.getElementById("resultText");
const metricReviews = document.getElementById("metricReviews");
const metricEmotion = document.getElementById("metricEmotion");
const metricSentiment = document.getElementById("metricSentiment");
const metricRisk = document.getElementById("metricRisk");
const reportLink = document.getElementById("reportLink");
const tiltCard = document.querySelector(".tilt-card");
const MIN_REVIEW_LIMIT = 10;
const MAX_REVIEW_LIMIT = 500;

const sampleReviews = [
  "Шланг мягкий, легкий, удобно поливать огород. За свою цену хороший вариант.",
  "Через неделю начал протекать возле соединения, качество слабое.",
  "Длина соответствует описанию, давление держит нормально, доставка быстрая.",
  "Пластик на фитинге хлипкий, после пары использований появились заломы.",
  "Отличный шланг, не дубеет и удобно сматывается после полива."
].join("\n\n");

async function checkBackend() {
  try {
    const response = await fetch(`${API_URL}/health`);
    if (!response.ok) throw new Error("bad status");
    backendStatus.textContent = "API подключен";
    backendStatus.classList.remove("bad");
    backendStatus.classList.add("ok");
  } catch (error) {
    backendStatus.textContent = "API недоступен";
    backendStatus.classList.remove("ok");
    backendStatus.classList.add("bad");
  }
}

function getReviewLimit(options = {}) {
  const parsed = Number.parseInt(reviewLimitEl.value, 10);
  const fallback = 120;
  const rawValue = Number.isFinite(parsed) ? parsed : fallback;
  const clamped = Math.max(MIN_REVIEW_LIMIT, Math.min(rawValue, MAX_REVIEW_LIMIT));
  if (reviewLimitEl.value !== String(clamped)) {
    reviewLimitEl.value = String(clamped);
    if (options.notify) {
      resultTitle.textContent = `Лимит отзывов: от ${MIN_REVIEW_LIMIT} до ${MAX_REVIEW_LIMIT}`;
      resultText.textContent = `Ты указал ${Number.isFinite(parsed) ? parsed : "пустое значение"}, поэтому анализ пойдет по ${clamped} отзывам.`;
    }
  }
  return clamped;
}

function formatSource(source) {
  const labels = {
    "2gis_visible_text": "2ГИС",
    "yandex_eda_modal": "Яндекс Еда",
    "tophotels_visible_text": "TopHotels",
    "otzovik_visible": "Отзовик",
    "irecommend_visible": "IRecommend",
    "visible_page": "Страница",
    "visible_page_text": "Текст страницы",
    "selected_text": "Выделенный текст",
    "manual_input": "Ручной ввод"
  };
  return labels[source] || String(source || "-").replace(/_/g, " ");
}

function parseReviews(text) {
  return text
    .split(/\n\s*\n|\n(?=.{20,})/g)
    .map((item) => item.replace(/\s+/g, " ").trim())
    .filter((item) => item.length >= 12)
    .slice(0, getReviewLimit())
    .map((text) => ({ source: "manual_input", text }));
}

function setLoading(isLoading) {
  analyzeButton.disabled = isLoading;
  analyzeButton.textContent = isLoading ? "Формирую отчет..." : "Сформировать отчет";
}

function renderResult(analysis) {
  resultTitle.textContent = analysis.object.name || "Анализ готов";
  resultText.textContent = analysis.summary?.overall_review || analysis.source?.message || "Отчет сформирован.";
  metricReviews.textContent = analysis.summary.total_reviews;
  metricEmotion.textContent = analysis.summary.dominant_emotion;
  metricSentiment.textContent = analysis.summary.dominant_sentiment;
  metricRisk.textContent = analysis.summary.risk_level || "-";
  reportLink.href = analysis.report_url;
  reportLink.classList.remove("disabled");
}

analysisForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const reviewLimit = getReviewLimit({ notify: true });
  setLoading(true);
  reportLink.classList.add("disabled");

  const inlineReviews = parseReviews(reviewsTextEl.value);
  const payload = {
    object_name: objectNameEl.value.trim(),
    source_url: sourceUrlEl.value.trim(),
    max_reviews: reviewLimit,
    inline_reviews: inlineReviews,
    page_text: `${objectNameEl.value} ${sourceUrlEl.value}`
  };

  try {
    const response = await fetch(`${API_URL}/api/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error("analysis failed");
    renderResult(await response.json());
  } catch (error) {
    resultTitle.textContent = "Не удалось выполнить анализ";
    resultText.textContent = "Проверь, что backend запущен на localhost:8765.";
  } finally {
    setLoading(false);
  }
});

sampleButton.addEventListener("click", () => {
  objectNameEl.value = "Шланг поливочный силикон 3/4 25 метров";
  sourceUrlEl.value = "https://www.ozon.ru/product/shlang-polivochnyy-silikon-3-4-25-metrov-3464230675/";
  reviewsTextEl.value = sampleReviews;
});

clearButton.addEventListener("click", () => {
  objectNameEl.value = "";
  sourceUrlEl.value = "";
  reviewLimitEl.value = "120";
  reviewsTextEl.value = "";
});

checkBackend();

reviewLimitEl.addEventListener("change", () => getReviewLimit({ notify: true }));

if (tiltCard) {
  const resetTilt = () => {
    tiltCard.style.transform = "rotateX(9deg) rotateY(-16deg) rotateZ(2deg)";
  };

  tiltCard.addEventListener("pointermove", (event) => {
    const rect = tiltCard.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    tiltCard.style.transform = `rotateX(${9 - y * 8}deg) rotateY(${-16 + x * 12}deg) rotateZ(2deg)`;
  });

  tiltCard.addEventListener("pointerleave", resetTilt);
}
