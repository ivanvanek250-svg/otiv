from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parent
DEMO_REVIEWS_PATH = ROOT / "demo_reviews.json"
SENTIMENT_MODEL_PATH = ROOT.parent / "models" / "rureviews_sentiment_model.json"
YANDEX_GEO_SENTIMENT_MODEL_PATH = ROOT.parent / "models" / "yandex_geo_sentiment_model.json"
TRANSFORMER_SENTIMENT_DIR = ROOT.parent / "models" / "rubert_sentiment"
TRANSFORMER_SENTIMENT_METADATA_PATH = TRANSFORMER_SENTIMENT_DIR / "training_metadata.json"
ASPECT_MODEL_PATH = ROOT.parent / "models" / "sentirueval_aspect_model.json"
SENTIMENT_MODEL_CACHE: dict[str, Any] | None = None
TRANSFORMER_SENTIMENT_CACHE: dict[str, Any] | None = None
ASPECT_MODEL_CACHE: dict[str, Any] | None = None
MODEL_INFO_CACHE: dict[str, Any] | None = None


EMOTION_KEYWORDS: dict[str, list[str]] = {
    "радость": [
        "отлич",
        "понрав",
        "спасибо",
        "вкусн",
        "уют",
        "прият",
        "любим",
        "хорош",
        "класс",
        "довол",
        "вернуться",
    ],
    "гнев": [
        "злю",
        "ужас",
        "груб",
        "отказ",
        "испорч",
        "не совет",
        "больше брать не будем",
        "кошмар",
    ],
    "разочарование": [
        "разочаров",
        "недоволен",
        "ожидал",
        "плохо",
        "слаб",
        "хлип",
        "не понрав",
        "меньше",
        "не будем",
        "нормальн",
    ],
    "тревога": [
        "страш",
        "опас",
        "покраснен",
        "плакал",
        "влажн",
        "химическ",
        "гарант",
    ],
    "удивление": [
        "не ожид",
        "удив",
        "внезап",
        "оказался",
    ],
}


ASPECT_KEYWORDS: dict[str, list[str]] = {
    "качество продукта": [
        "кофе",
        "капучино",
        "раф",
        "вкус",
        "кисл",
        "холодн",
        "выпеч",
        "подгузник",
        "мягк",
        "тонк",
        "впитыв",
        "протека",
        "запах",
        "шланг",
        "соединен",
        "фитинг",
        "давлен",
        "течь",
    ],
    "скорость обслуживания": [
        "ждали",
        "минут",
        "долго",
        "очеред",
        "быстр",
        "срок",
        "растянул",
        "предупрежден",
        "задерж",
        "выдач",
    ],
    "персонал": [
        "персонал",
        "бариста",
        "мастер",
        "сотрудник",
        "груб",
        "ответил",
        "объяснил",
        "улыб",
    ],
    "цена": [
        "цена",
        "дорог",
        "дешев",
        "стоимость",
        "за свою цену",
        "выше",
    ],
    "атмосфера и место": [
        "уют",
        "атмосфер",
        "музыка",
        "располож",
        "столик",
        "чист",
        "спокойн",
    ],
    "номер и размещение": [
        "номер",
        "размещение",
        "засел",
        "кровать",
        "санузел",
        "кондиционер",
        "балкон",
        "вид из окна",
        "шум",
        "плесень",
        "уборк",
        "полотенц",
    ],
    "питание": [
        "завтрак",
        "обед",
        "ужин",
        "питание",
        "еда",
        "шведск",
        "ресторан",
        "напитк",
        "свеж",
        "невкус",
    ],
    "сервис отеля": [
        "ресепшн",
        "администратор",
        "анимац",
        "персонал",
        "уборк",
        "заменили",
        "попросили",
        "заселили",
        "помогли",
    ],
    "упаковка и доставка": [
        "достав",
        "упаков",
        "пачка",
        "целая",
        "курьер",
    ],
    "размер и соответствие": [
        "размер",
        "маломер",
        "тесн",
        "сетка",
        "соответств",
    ],
    "материал": [
        "материал",
        "кожа",
        "кожан",
        "замша",
        "ткань",
        "резин",
        "пластик",
        "искусствен",
    ],
    "долговечность": [
        "развал",
        "сломал",
        "стер",
        "порвал",
        "протек",
        "течет",
        "залом",
        "хлип",
        "хватит",
        "недел",
        "месяц",
        "износ",
        "низш",
    ],
    "безопасность и здоровье": [
        "раздраж",
        "покраснен",
        "ребенок",
        "плакал",
        "химическ",
    ],
    "гарантия и надежность": [
        "гарант",
        "сломал",
        "выключ",
        "ремонт",
        "отказ",
    ],
}


POSITIVE_WORDS = {
    "отлич",
    "понрав",
    "спасибо",
    "вкусн",
    "уют",
    "прият",
    "хорош",
    "быстр",
    "мягк",
    "удобн",
    "достой",
    "красив",
    "вежлив",
    "свеж",
    "чист",
    "простор",
    "помогли",
}

NEGATIVE_WORDS = {
    "плохо",
    "ужас",
    "груб",
    "долго",
    "холодн",
    "грязн",
    "протека",
    "разочаров",
    "недоволен",
    "тесн",
    "химическ",
    "отказ",
    "испорч",
    "низш",
    "развал",
    "стер",
    "протек",
    "хлип",
    "залом",
    "слаб",
    "растянул",
    "без предупреждения",
    "не хватит",
    "невкус",
    "плесень",
    "шум",
    "хам",
    "обман",
    "стар",
    "вон",
    "пятн",
}

STRONG_POSITIVE_PATTERNS = (
    "ахуен",
    "пиздат",
    "бомба",
    "топ",
    "кайф",
    "круто",
    "класс",
    "супер",
    "огонь",
    "молодцы",
    "лучшие",
    "прекрас",
    "отлич",
    "хорош",
    "вкусн",
    "сочн",
    "недорог",
    "быстр",
    "разнообраз",
    "большой выбор",
    "неубиваемая классика",
)

STRONG_NEGATIVE_PATTERNS = (
    "говн",
    "дерьм",
    "не съедоб",
    "несъедоб",
    "невкус",
    "не вкус",
    "таракан",
    "гряз",
    "хам",
    "не дали",
    "не полож",
    "не доклад",
    "половину",
    "медлен",
    "долго",
    "ждали",
    "прожд",
    "дорог",
    "болит живот",
    "закрыт",
    "не убирают",
    "дефицит",
    "не ногой",
    "не очень понрав",
    "👎",
)

MIXED_LATIN_TO_CYRILLIC = str.maketrans(
    {
        "a": "а",
        "c": "с",
        "e": "е",
        "k": "к",
        "m": "м",
        "n": "н",
        "o": "о",
        "p": "р",
        "t": "т",
        "x": "х",
        "y": "у",
    }
)

STOPWORDS = {
    "это",
    "как",
    "что",
    "все",
    "для",
    "или",
    "при",
    "так",
    "уже",
    "еще",
    "очень",
    "было",
    "были",
    "есть",
    "нет",
    "меня",
    "мне",
    "нас",
    "нам",
    "они",
    "она",
    "его",
    "его",
    "этот",
    "этой",
    "этом",
    "тоже",
    "только",
    "после",
    "пока",
    "если",
    "когда",
    "потому",
    "просто",
    "более",
    "менее",
    "свой",
    "свою",
    "свои",
    "брать",
    "купил",
    "купила",
    "заказ",
    "отзыв",
}


def load_demo_reviews() -> list[dict[str, Any]]:
    with DEMO_REVIEWS_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)


def remove_review_noise(text: str) -> str:
    text = re.sub(r"[\u200b-\u200f\u202a-\u202e\ufff6]", " ", text)
    text = re.sub(r"\bОплата\s+(?:Т-?Банк|Сбер|картой|наличными)\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_mixed_cyrillic(text: str) -> str:
    return text.lower().replace("ё", "е").translate(MIXED_LATIN_TO_CYRILLIC)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", normalize_mixed_cyrillic(remove_review_noise(text))).strip()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zа-я0-9]+", normalize(text))


def guess_object_type(text: str) -> str:
    lowered = normalize(text)
    product_markers = ["подгуз", "товар", "размер", "бренд", "купить", "маркет"]
    org_markers = ["кофейн", "кафе", "ресторан", "салон", "сервис", "адрес", "карты"]
    if any(marker in lowered for marker in product_markers):
        return "товар"
    if any(marker in lowered for marker in org_markers):
        return "организация"
    return "объект"


def infer_object_name(payload: dict[str, Any]) -> str:
    explicit = str(payload.get("object_name") or "").strip()
    if explicit:
        return explicit[:120]

    for key in ("title", "h1", "meta_description"):
        value = str(payload.get(key) or "").strip()
        if value:
            return cleanup_title(value)

    page_text = str(payload.get("page_text") or "").strip()
    first_line = next((line.strip() for line in page_text.splitlines() if line.strip()), "")
    return cleanup_title(first_line or "Объект анализа")


def cleanup_title(title: str) -> str:
    title = re.sub(r"\s+", " ", title).strip()
    title = re.split(r"\s[|•—-]\s", title)[0].strip()
    return title[:120] or "Объект анализа"


def relevance_score(review: dict[str, Any], query: str) -> float:
    query_tokens = set(tokenize(query))
    object_tokens = set(tokenize(str(review.get("object", ""))))
    text_tokens = set(tokenize(str(review.get("text", ""))))

    if not query_tokens:
        return 0

    object_overlap = len(query_tokens & object_tokens)
    text_overlap = len(query_tokens & text_tokens)
    category_bonus = 0

    lowered = normalize(query)
    category = review.get("category")
    if category == "coffee_shop" and any(word in lowered for word in ("кофе", "кофейн", "ашот")):
        category_bonus = 2
    if category == "diapers" and any(word in lowered for word in ("подгуз", "агуш", "детск")):
        category_bonus = 2
    if category == "service" and any(word in lowered for word in ("ремонт", "телефон", "сервис")):
        category_bonus = 2

    return object_overlap * 3 + text_overlap * 0.4 + category_bonus


def find_reviews(query: str, page_text: str = "", limit: int = 24) -> list[dict[str, Any]]:
    search_text = query
    demo_reviews = load_demo_reviews()
    ranked = sorted(
        ((relevance_score(review, search_text), review) for review in demo_reviews),
        key=lambda item: item[0],
        reverse=True,
    )

    selected = [review for score, review in ranked if score >= 2][:limit]
    return selected


def is_external_source_url(source_url: str) -> bool:
    if not source_url:
        return False
    parsed = urlparse(source_url)
    if parsed.scheme not in {"http", "https"}:
        return False
    host = (parsed.hostname or "").lower()
    return host not in {"localhost", "127.0.0.1", "::1"}


REVIEW_START_RE = re.compile(
    r"(?=(?:^|\s)(?:[А-ЯЁA-Z]\s+)?[А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Z]\.)?\s+"
    r"\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+20\d{2})",
    re.IGNORECASE,
)


def split_review_blob(text: str) -> list[str]:
    text = re.sub(r"\s+", " ", text).strip()
    starts = [match.start() for match in REVIEW_START_RE.finditer(text)]
    if len(starts) <= 1:
        return [text]

    starts.append(len(text))
    parts = []
    for index in range(len(starts) - 1):
        part = text[starts[index] : starts[index + 1]].strip()
        if part:
            parts.append(part)
    return parts


def clean_review_text(text: str) -> str:
    text = remove_review_noise(re.sub(r"\s+", " ", text).strip())
    text = re.sub(
        r"^(?:[А-ЯЁA-Z]\s+)?[А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Z]\.)?\s+"
        r"\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+20\d{2}\s+",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"Вам помог(?:\s+этот)?\s+отзыв\?\s*Да\s*\d+\s*Нет\s*\d+", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"Отзыв выбран компанией|Отзыв подтвержд[её]н|Полезно\?", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"Читать\s+(?:целиком|весь\s+отзыв|полностью)", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\d+\s+посещени[еяй]", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(?:Российский размер|Размер производителя)\s*:\s*\S+[,;]?\s*", " ", text, flags=re.IGNORECASE)
    text = re.sub(
        r"\b(?:Цвет товара|Название цвета|Комплектация|Артикул|Бренд)\s*:\s*[^,.;!?]{1,70}[,;]?\s*",
        " ",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"\b(?:Достоинства|Недостатки|Комментарий)\s*:\s*", " ", text, flags=re.IGNORECASE)
    text = remove_review_noise(re.sub(r"\s+", " ", text).strip(" ,.;"))
    return text


def is_noise_review_text(text: str) -> bool:
    normalized = re.sub(r"\s+", " ", text).strip()
    lowered = normalized.lower()
    subscribe_count = len(re.findall(r"подписаться", normalized, flags=re.IGNORECASE))
    expert_count = len(
        re.findall(
            r"знаток города|пишет отзывы|оставляет отзывы|разбирается|часто пишет|много отзывов",
            normalized,
            flags=re.IGNORECASE,
        )
    )
    return (
        bool(re.match(r"^,?\s*официальный ответ\b", normalized, flags=re.IGNORECASE))
        or bool(
            re.search(
                r"\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+20\d{2},\s*официальный ответ",
                normalized,
                flags=re.IGNORECASE,
            )
        )
        or
        lowered.startswith("рекомендации для вас")
        or ("показать все" in lowered and subscribe_count >= 2)
        or subscribe_count >= 3
        or expert_count >= 2
    )


def inline_reviews_from_payload(payload: dict[str, Any], limit: int = 300) -> list[dict[str, Any]]:
    raw_reviews = payload.get("inline_reviews") or []
    if not isinstance(raw_reviews, list):
        return []

    reviews = []
    seen: set[str] = set()
    for raw in raw_reviews:
        if isinstance(raw, dict):
            text = str(raw.get("text") or "")
            source = str(raw.get("source") or "visible_page")
            rating = raw.get("rating")
        else:
            text = str(raw)
            source = "visible_page"
            rating = None

        if is_noise_review_text(text):
            continue
        for candidate in split_review_blob(text):
            cleaned_text = clean_review_text(candidate)
            if is_noise_review_text(cleaned_text):
                continue
            fingerprint = normalize(cleaned_text)[:220]
            if len(cleaned_text) < 4 or (len(cleaned_text) < 12 and not has_short_review_signal(cleaned_text)) or fingerprint in seen:
                continue
            seen.add(fingerprint)
            reviews.append(
                {
                    "object": str(payload.get("object_name") or payload.get("title") or "Страница"),
                    "category": "visible_page",
                    "source": source,
                    "rating": rating if isinstance(rating, (int, float)) else None,
                    "text": cleaned_text[:1200],
                }
            )
            if len(reviews) >= limit:
                break
        if len(reviews) >= limit:
            break
    return reviews


def read_review_limit(payload: dict[str, Any], default: int = 120) -> int:
    try:
        raw_limit = int(payload.get("max_reviews") or default)
    except (TypeError, ValueError):
        raw_limit = default
    return max(10, min(raw_limit, 500))


def score_by_keywords(text: str, dictionary: dict[str, list[str]]) -> dict[str, float]:
    lowered = normalize(text)
    scores: dict[str, float] = {}
    for label, keywords in dictionary.items():
        score = 0.0
        for keyword in keywords:
            if keyword in lowered:
                score += 1.0 + min(len(keyword) / 20, 0.5)
        if score:
            scores[label] = score
    return scores


def load_aspect_model() -> dict[str, Any] | None:
    global ASPECT_MODEL_CACHE
    if ASPECT_MODEL_CACHE is not None:
        return ASPECT_MODEL_CACHE
    if not ASPECT_MODEL_PATH.exists():
        return None
    try:
        ASPECT_MODEL_CACHE = json.loads(ASPECT_MODEL_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return ASPECT_MODEL_CACHE


def score_aspects_with_model(text: str) -> dict[str, float]:
    payload = load_aspect_model()
    if not payload:
        return {}

    model = payload.get("model", {})
    word_counts = model.get("word_counts", {})
    tokens = tokenize(text)
    if not tokens:
        return {}

    scores: dict[str, float] = {}
    for label, counts in word_counts.items():
        score = 0.0
        for token in tokens:
            count = counts.get(token, 0)
            if count:
                score += 0.35 + min(math.log1p(count) / 3, 1.2)
        if score >= 2.0:
            scores[label] = score
    return scores


def detect_emotion(text: str, rating: int | float | None = None) -> dict[str, Any]:
    scores = score_by_keywords(text, EMOTION_KEYWORDS)
    explicit = explicit_sentiment(text)
    lowered = normalize(text)
    if explicit == "позитив":
        scores["радость"] = scores.get("радость", 0) + 1.4
    elif explicit == "негатив":
        scores.pop("радость", None)
        if any(marker in lowered for marker in ("говн", "таракан", "гряз", "хам", "не дали", "не полож", "не доклад", "👎")):
            scores["гнев"] = scores.get("гнев", 0) + 1.2
        else:
            scores["разочарование"] = scores.get("разочарование", 0) + 1.0
    if rating is not None:
        if rating >= 4:
            scores["радость"] = scores.get("радость", 0) + 1.2
        elif rating <= 2:
            scores["разочарование"] = scores.get("разочарование", 0) + 0.8
            scores["гнев"] = scores.get("гнев", 0) + 0.4

    if not scores:
        return {"label": "нейтрально", "confidence": 0.52, "scores": {"нейтрально": 1}}

    label, value = max(scores.items(), key=lambda item: item[1])
    total = sum(scores.values())
    confidence = 0.5 + min(value / max(total, 1), 1) * 0.45
    return {"label": label, "confidence": round(confidence, 2), "scores": scores}


def reconcile_emotion_with_sentiment(
    emotion: dict[str, Any],
    sentiment: str,
    text: str,
    rating: int | float | None = None,
) -> dict[str, Any]:
    label = str(emotion.get("label") or "")
    lowered = normalize(text)

    if sentiment == "негатив" and label == "радость":
        scores = {key: float(value) for key, value in dict(emotion.get("scores") or {}).items() if key != "радость"}
        angry_markers = (
            "ужас",
            "говн",
            "дерьм",
            "хам",
            "невеж",
            "обман",
            "очеред",
            "гряз",
            "тарак",
            "неуют",
            "не совет",
            "больше не",
            "не ногой",
        )
        target = "гнев" if any(marker in lowered for marker in angry_markers) else "разочарование"
        scores[target] = max(scores.get(target, 0.0), 1.4)
        if rating is not None and rating <= 2:
            scores["разочарование"] = max(scores.get("разочарование", 0.0), 1.1)
        value = scores[target]
        total = sum(scores.values()) or value
        confidence = 0.58 + min(value / max(total, 1), 1) * 0.37
        return {"label": target, "confidence": round(confidence, 2), "scores": scores}

    if sentiment == "позитив" and label in {"гнев", "разочарование", "тревога"}:
        scores = dict(emotion.get("scores") or {})
        scores["радость"] = max(float(scores.get("радость", 0.0)), 1.3)
        scores.pop("гнев", None)
        label = "радость"
        value = scores[label]
        total = sum(float(score) for score in scores.values()) or value
        confidence = 0.56 + min(value / max(total, 1), 1) * 0.38
        return {"label": label, "confidence": round(confidence, 2), "scores": scores}

    return emotion


def load_sentiment_model() -> dict[str, Any] | None:
    global SENTIMENT_MODEL_CACHE
    if SENTIMENT_MODEL_CACHE is not None:
        return SENTIMENT_MODEL_CACHE
    model_path = next(
        (path for path in (YANDEX_GEO_SENTIMENT_MODEL_PATH, SENTIMENT_MODEL_PATH) if path.exists()),
        None,
    )
    if model_path is None:
        return None
    try:
        SENTIMENT_MODEL_CACHE = json.loads(model_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return SENTIMENT_MODEL_CACHE


def predict_sentiment_with_model(text: str) -> str | None:
    payload = load_sentiment_model()
    if not payload:
        return None

    model = payload.get("model", {})
    label_counts = model.get("label_counts", {})
    word_counts = model.get("word_counts", {})
    total_words = model.get("total_words", {})
    vocabulary = set(model.get("vocabulary", []))
    labels = list(label_counts)
    if not labels:
        return None

    tokens = [token for token in tokenize(text) if token in vocabulary]
    total_docs = sum(label_counts.values())
    vocab_size = max(len(vocabulary), 1)
    scores: dict[str, float] = {}
    for label in labels:
        score = math.log(label_counts[label] / total_docs)
        denominator = total_words.get(label, 0) + vocab_size
        label_word_counts = word_counts.get(label, {})
        for token in tokens:
            score += math.log((label_word_counts.get(token, 0) + 1) / denominator)
        scores[label] = score

    return max(scores.items(), key=lambda item: item[1])[0]


def load_transformer_sentiment_model() -> dict[str, Any] | None:
    global TRANSFORMER_SENTIMENT_CACHE
    if TRANSFORMER_SENTIMENT_CACHE is not None:
        return TRANSFORMER_SENTIMENT_CACHE
    if not TRANSFORMER_SENTIMENT_DIR.exists():
        return None

    try:
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
    except Exception:
        return None

    try:
        tokenizer = AutoTokenizer.from_pretrained(str(TRANSFORMER_SENTIMENT_DIR), local_files_only=True)
        model = AutoModelForSequenceClassification.from_pretrained(
            str(TRANSFORMER_SENTIMENT_DIR),
            local_files_only=True,
        )
    except Exception:
        return None

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()
    id2label = {
        int(index): label
        for index, label in getattr(model.config, "id2label", {}).items()
    }
    TRANSFORMER_SENTIMENT_CACHE = {
        "torch": torch,
        "tokenizer": tokenizer,
        "model": model,
        "device": device,
        "id2label": id2label,
    }
    return TRANSFORMER_SENTIMENT_CACHE


def predict_sentiment_with_transformer(text: str) -> str | None:
    payload = load_transformer_sentiment_model()
    if not payload:
        return None

    torch = payload["torch"]
    tokenizer = payload["tokenizer"]
    model = payload["model"]
    device = payload["device"]
    id2label = payload["id2label"]

    try:
        encoded = tokenizer(
            text[:2000],
            truncation=True,
            max_length=192,
            return_tensors="pt",
        )
        encoded = {key: value.to(device) for key, value in encoded.items()}
        with torch.no_grad():
            logits = model(**encoded).logits[0]
            probabilities = torch.softmax(logits, dim=-1)
            confidence, label_id = torch.max(probabilities, dim=-1)
        if float(confidence) < 0.45:
            return None
        return id2label.get(int(label_id))
    except Exception:
        return None


def score_explicit_sentiment(text: str) -> tuple[int, int]:
    lowered = normalize(text)
    positive = sum(2 for pattern in STRONG_POSITIVE_PATTERNS if pattern in lowered)
    negative = sum(2 for pattern in STRONG_NEGATIVE_PATTERNS if pattern in lowered)
    positive += sum(1 for word in POSITIVE_WORDS if word in lowered)
    negative += sum(1 for word in NEGATIVE_WORDS if word in lowered)

    if re.search(r"\bне\s+(?:очень\s+)?(?:вкусн|понрав|съедоб|долож|полож|дали|убира)", lowered):
        negative += 3
    if re.search(r"\b(?:без|нет)\s+(?:ложк|бург|картош|кольц|заказ)", lowered):
        negative += 2
    if "дороговато" in lowered or "стало дорого" in lowered:
        negative += 2
    if re.search(r"(задрал\w*\s+цен|цены?.*(?:дорог|дешевле)|все\s+дешевле)", lowered):
        negative += 4
    if re.search(r"(невежлив|неуют|очеред|не\s+годится|недоволь|желания\s+нет|не\s+совет|не\s+отвечает|обман|ужас)", lowered):
        negative += 3
    if "невежлив" in lowered:
        positive = max(0, positive - 1)
        negative += 3
    if "задрал" in lowered and "цен" in lowered:
        negative += 3
    if re.search(r"\bне\s+(?:может\s+быть\s+)?(?:нормальн|хорош|вкусн|съедоб|понрав)", lowered):
        negative += 2
    if "нормально" in lowered or "пойдет" in lowered:
        positive += 1
    return positive, negative


def explicit_sentiment(text: str) -> str | None:
    positive, negative = score_explicit_sentiment(text)
    token_count = len(tokenize(text))
    if negative >= positive + 2 and (negative >= 3 or token_count <= 8):
        return "негатив"
    if positive >= negative + 2 and (positive >= 3 or token_count <= 8):
        return "позитив"
    return None


def has_short_review_signal(text: str) -> bool:
    lowered = normalize(text)
    if score_explicit_sentiment(text) != (0, 0):
        return True
    aspect_markers = (
        "бургер",
        "воппер",
        "картош",
        "кофе",
        "еда",
        "цена",
        "акци",
        "гряз",
        "туалет",
        "таракан",
        "персонал",
        "обслуж",
        "сервис",
        "доставка",
        "быстро",
        "медлен",
        "дорог",
        "вкус",
    )
    return any(marker in lowered for marker in aspect_markers)


def load_training_metadata() -> dict[str, Any] | None:
    if not TRANSFORMER_SENTIMENT_METADATA_PATH.exists():
        return None
    try:
        return json.loads(TRANSFORMER_SENTIMENT_METADATA_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def build_model_info() -> dict[str, Any]:
    global MODEL_INFO_CACHE
    if MODEL_INFO_CACHE is not None:
        return MODEL_INFO_CACHE

    metadata = load_training_metadata() or {}
    metrics = metadata.get("metrics", {}).get("trainer_metrics", {})
    transformer_payload = load_transformer_sentiment_model()
    sentiment_status = "active" if transformer_payload else "fallback"
    sentiment_model = {
        "name": "RuBERT-tiny",
        "status": sentiment_status,
        "runtime": "transformers" if transformer_payload else "Naive Bayes fallback",
        "model_name": metadata.get("model_name", "cointegrated/rubert-tiny2"),
        "dataset_name": metadata.get("dataset", {}).get("name", "RuReviews"),
        "dataset_size": metadata.get("dataset_size"),
        "train_size": metadata.get("train_size"),
        "validation_size": metadata.get("validation_size"),
        "test_size": metadata.get("test_size"),
        "accuracy": metrics.get("test_accuracy"),
        "f1_macro": metrics.get("test_f1_macro"),
        "precision_macro": metrics.get("test_precision_macro"),
        "recall_macro": metrics.get("test_recall_macro"),
        "device": metadata.get("device"),
        "epochs": metadata.get("epochs"),
        "batch_size": metadata.get("batch_size"),
        "trained_at": metadata.get("trained_at"),
    }
    aspect_model = {
        "name": "SentiRuEval + словарные правила",
        "status": "active" if ASPECT_MODEL_PATH.exists() else "rules_only",
        "task": "aspect_extraction",
    }
    MODEL_INFO_CACHE = {
        "sentiment": sentiment_model,
        "aspect": aspect_model,
    }
    return MODEL_INFO_CACHE


def detect_sentiment(text: str, rating: int | float | None = None) -> str:
    explicit = explicit_sentiment(text)
    if explicit:
        return explicit

    transformer_sentiment = predict_sentiment_with_transformer(text)
    if transformer_sentiment:
        if rating is not None and rating <= 2 and transformer_sentiment == "позитив":
            return "негатив"
        if rating is not None and rating >= 4 and transformer_sentiment == "негатив":
            return "позитив"
        return transformer_sentiment

    model_sentiment = predict_sentiment_with_model(text)
    if model_sentiment:
        if rating is not None and rating <= 2 and model_sentiment == "позитив":
            return "негатив"
        if rating is not None and rating >= 4 and model_sentiment == "негатив":
            return "позитив"
        return model_sentiment

    lowered = normalize(text)
    positive = sum(1 for word in POSITIVE_WORDS if word in lowered)
    negative = sum(1 for word in NEGATIVE_WORDS if word in lowered)

    if rating is not None:
        if rating >= 4:
            positive += 2
        elif rating <= 2:
            negative += 2

    if positive > negative:
        return "позитив"
    if negative > positive:
        return "негатив"
    return "нейтрально"


def extract_aspects(text: str) -> list[dict[str, Any]]:
    scores = score_by_keywords(text, ASPECT_KEYWORDS)
    model_scores = score_aspects_with_model(text)
    for label, score in model_scores.items():
        scores[label] = scores.get(label, 0) + score * 0.65

    lowered = normalize(text)
    product_context = ("бургер", "воппер", "картош", "кофе", "еда", "съедоб", "вкус", "изжог", "сытн", "ассортимент", "выбор", "доклад", "полож", "качеств")
    atmosphere_context = ("гряз", "туалет", "таракан", "помещ", "стол", "жарко", "чист", "стар")
    person_context = ("персонал", "сотруд", "хам", "обслуж", "сервис", "девушк", "кассир")
    price_context = ("дорог", "недорог", "цена", "акци", "руб")
    warranty_context = ("гаран", "надеж", "постоянно", "вечно", "раньше", "всегда", "третий раз", "каждый раз", "доклад")

    if any(marker in lowered for marker in product_context):
        scores["качество продукта"] = scores.get("качество продукта", 0) + 4.0
    if any(marker in lowered for marker in atmosphere_context):
        scores["атмосфера и место"] = scores.get("атмосфера и место", 0) + 4.0
    if any(marker in lowered for marker in person_context):
        scores["персонал"] = scores.get("персонал", 0) + 4.0
    if any(marker in lowered for marker in ("медлен", "долго", "ждал", "ждали", "прожд", "быстро", "выдач")):
        scores["скорость обслуживания"] = scores.get("скорость обслуживания", 0) + 4.0
    if any(marker in lowered for marker in price_context):
        scores["цена"] = scores.get("цена", 0) + 4.0
    if any(marker in lowered for marker in ("не полож", "не доклад", "не дали", "ложк", "кольц", "доставка", "доставили")):
        scores["упаковка и доставка"] = scores.get("упаковка и доставка", 0) + 4.0

    service_context = ("ждали", "очеред", "выдач", "обслуж", "заказ", "достав", "бариста", "персонал", "медлен", "работ")
    health_context = ("раздраж", "покраснен", "ребенок", "плакал", "химическ", "аллерг")
    hotel_context = ("отель", "номер", "размещ", "ресепшн", "засел", "гость", "тур", "пляж", "уборк", "питани", "top hotels", "tophotels")

    if "скорость обслуживания" in scores and not any(marker in lowered for marker in service_context):
        del scores["скорость обслуживания"]
    if "качество продукта" in scores and not any(marker in lowered for marker in product_context):
        del scores["качество продукта"]
    if "атмосфера и место" in scores and not any(marker in lowered for marker in atmosphere_context):
        del scores["атмосфера и место"]
    if "персонал" in scores and not any(marker in lowered for marker in person_context):
        del scores["персонал"]
    if "цена" in scores and not any(marker in lowered for marker in price_context):
        del scores["цена"]
    if "гарантия и надежность" in scores and not any(marker in lowered for marker in warranty_context):
        del scores["гарантия и надежность"]
    if "безопасность и здоровье" in scores and not any(marker in lowered for marker in health_context):
        del scores["безопасность и здоровье"]
    for hotel_aspect in ("номер и размещение", "питание", "сервис отеля"):
        if hotel_aspect in scores and not any(marker in lowered for marker in hotel_context):
            del scores[hotel_aspect]

    if not scores:
        return [{"label": "общее впечатление", "confidence": 0.45}]

    total = sum(scores.values())
    aspects = [
        {"label": label, "confidence": round(0.45 + (score / total) * 0.5, 2)}
        for label, score in sorted(scores.items(), key=lambda item: item[1], reverse=True)
    ]
    return aspects[:3]


def problem_recommendation(aspect: str) -> str:
    recommendations = {
        "качество продукта": "Проверить стабильность качества продукта и отдельно разобрать отзывы с конкретными дефектами.",
        "скорость обслуживания": "Проанализировать нагрузку в часы пик и сократить время ожидания клиента.",
        "персонал": "Разобрать спорные обращения и обновить стандарты коммуникации с клиентами.",
        "цена": "Проверить восприятие цены: добавить объяснение ценности, акции или более понятные комплектации.",
        "атмосфера и место": "Проверить чистоту, удобство посадки и общее состояние пространства.",
        "номер и размещение": "Проверить состояние номеров, уборку и частые жалобы на заселение или шум.",
        "питание": "Разобрать качество блюд, свежесть продуктов и повторяющиеся претензии к меню.",
        "сервис отеля": "Проверить работу ресепшна, уборки и скорость реакции персонала на просьбы гостей.",
        "упаковка и доставка": "Проверить качество упаковки и сроки доставки на проблемных заказах.",
        "размер и соответствие": "Уточнить размерную сетку и добавить подсказки по выбору размера.",
        "материал": "Проверить описание материала в карточке товара и добавить честные характеристики состава.",
        "долговечность": "Проверить качество партии и отдельно разобрать отзывы о поломках, износе и малом сроке службы.",
        "безопасность и здоровье": "Приоритизировать проверку состава, материалов и жалоб на реакцию у клиентов.",
        "гарантия и надежность": "Проверить гарантийные сценарии и причины повторных обращений.",
    }
    return recommendations.get(aspect, "Изучить примеры негативных отзывов и выделить повторяющуюся причину.")


def strength_recommendation(aspect: str) -> str:
    recommendations = {
        "качество продукта": "Использовать этот аспект в позиционировании: клиенты уже подтверждают ценность качества.",
        "скорость обслуживания": "Поддерживать текущий темп и отдельно фиксировать практики, которые помогают обслуживать быстрее.",
        "персонал": "Закрепить сильные сценарии общения как стандарт сервиса и использовать их в обучении сотрудников.",
        "цена": "Подчеркнуть соотношение цены и ценности в карточке товара, меню или рекламных материалах.",
        "атмосфера и место": "Развивать визуальные и сервисные элементы, из-за которых клиенты хотят возвращаться.",
        "номер и размещение": "Показывать сильные стороны номеров в описании и фото, особенно если гости хвалят чистоту и удобство.",
        "питание": "Выделить удачные блюда, завтраки или формат питания как конкурентное преимущество.",
        "сервис отеля": "Сохранить сильные практики ресепшна, уборки и реакции на просьбы гостей.",
        "упаковка и доставка": "Использовать надежную упаковку и быструю доставку как аргумент доверия.",
        "размер и соответствие": "Сохранить точность описания и подсказки по выбору размера.",
        "материал": "Подчеркнуть материалы и свойства, которые клиенты называют удачными.",
        "долговечность": "Показывать подтверждения срока службы в описании и ответах на вопросы клиентов.",
        "безопасность и здоровье": "Выделить безопасность и отсутствие негативной реакции как ключевой критерий выбора.",
        "гарантия и надежность": "Подчеркнуть надежность и понятные гарантийные условия.",
    }
    return recommendations.get(aspect, "Сохранить этот аспект как сильную сторону и использовать в коммуникации с клиентами.")


def extract_key_terms(texts: list[str], limit: int = 5) -> list[str]:
    counter: Counter[str] = Counter()
    for text in texts:
        for token in tokenize(text):
            if len(token) < 4 or token in STOPWORDS:
                continue
            counter[token] += 1
    return [token for token, _ in counter.most_common(limit)]


def join_terms(terms: list[str]) -> str:
    if not terms:
        return "конкретные причины требуют ручной проверки примеров"
    if len(terms) == 1:
        return f"«{terms[0]}»"
    return ", ".join(f"«{term}»" for term in terms[:-1]) + f" и «{terms[-1]}»"


def build_aspect_explanation(aspect: str, positive_examples: list[str], negative_examples: list[str]) -> str:
    positive_terms = extract_key_terms(positive_examples)
    negative_terms = extract_key_terms(negative_examples)
    if positive_examples and negative_examples:
        return (
            f"Аспект «{aspect}» воспринимается неоднозначно: в позитивных отзывах чаще встречаются {join_terms(positive_terms)}, "
            f"а в негативных — {join_terms(negative_terms)}. Нужно сравнить ситуации, где клиент доволен, с ситуациями, где возникает претензия."
        )
    if negative_examples:
        return (
            f"Негатив по аспекту «{aspect}» чаще связан с темами {join_terms(negative_terms)}. "
            "Это стоит проверять первым, потому что жалобы повторяются в похожих формулировках."
        )
    if positive_examples:
        return (
            f"Аспект «{aspect}» работает как сильная сторона: клиенты чаще говорят про {join_terms(positive_terms)}. "
            "Эти формулировки можно использовать в описании продукта, сервиса или рекламных материалах."
        )
    return f"По аспекту «{aspect}» мало содержательных примеров, поэтому вывод лучше проверить вручную."


def build_risk_summary(total: int, sentiment_counter: Counter[str], problem_aspects: list[dict[str, Any]]) -> dict[str, Any]:
    if total == 0:
        return {
            "risk_level": "нет данных",
            "risk_score": 0,
            "next_step": "Сначала нужно собрать или выделить реальные отзывы.",
        }

    negative_share = sentiment_counter.get("негатив", 0) / total
    max_problem_share = max((item["share"] for item in problem_aspects), default=0)
    risk_score = min(1.0, negative_share * 0.7 + max_problem_share * 0.2 + min(len(problem_aspects), 4) * 0.04)

    if negative_share >= 0.35 or max_problem_share >= 0.25:
        level = "высокий"
        top_problem = problem_aspects[0]["aspect"] if problem_aspects else "повторяющиеся жалобы"
        next_step = f"Срочно разобрать аспект «{top_problem}» и проверить свежие негативные отзывы."
    elif negative_share >= 0.18 or len(problem_aspects) >= 2:
        level = "средний"
        top_problem = problem_aspects[0]["aspect"] if problem_aspects else "отдельные претензии"
        next_step = f"Запланировать проверку аспекта «{top_problem}» и сравнить его с позитивными упоминаниями."
    else:
        level = "низкий"
        next_step = "Поддерживать сильные стороны и периодически проверять новые отзывы."

    return {
        "risk_level": level,
        "risk_score": round(risk_score, 2),
        "next_step": next_step,
    }


def build_executive_summary(
    total: int,
    sentiment_counter: Counter[str],
    problem_aspects: list[dict[str, Any]],
    strength_aspects: list[dict[str, Any]],
) -> str:
    if total == 0:
        return "Отзывы не извлечены, поэтому выводы по эмоциям и аспектам пока не сформированы."

    positive = sentiment_counter.get("позитив", 0)
    negative = sentiment_counter.get("негатив", 0)
    neutral = sentiment_counter.get("нейтрально", 0)
    problem_item = problem_aspects[0] if problem_aspects else None
    strength_item = strength_aspects[0] if strength_aspects else None

    if problem_item and strength_item and problem_item["aspect"] == strength_item["aspect"]:
        aspect = problem_item["aspect"]
        return (
            f"Проанализировано {total} отзывов: позитивных {positive}, негативных {negative}, нейтральных {neutral}. "
            f"Аспект «{aspect}» поляризует клиентов: его одновременно часто хвалят и часто критикуют. "
            "Нужно отделить удачные сценарии от проблемных и проверить, в каких ситуациях возникает негатив."
        )

    problem = problem_item["aspect"] if problem_item else "критичных повторяющихся проблем не видно"
    strength = strength_item["aspect"] if strength_item else "сильная сторона не выражена явно"
    return (
        f"Проанализировано {total} отзывов: позитивных {positive}, негативных {negative}, нейтральных {neutral}. "
        f"Главная зона внимания: {problem}. Главная сильная сторона: {strength}."
    )


def build_overall_review(
    total: int,
    sentiment_counter: Counter[str],
    emotion_counter: Counter[str],
    problem_aspects: list[dict[str, Any]],
    strength_aspects: list[dict[str, Any]],
) -> str:
    if total == 0:
        return "Общий отзыв не сформирован: система не получила достаточный объем отзывов."

    positive = sentiment_counter.get("позитив", 0)
    negative = sentiment_counter.get("негатив", 0)
    neutral = sentiment_counter.get("нейтрально", 0)
    positive_share = positive / total
    negative_share = negative / total
    dominant_emotion = dominant_label(emotion_counter, "смешанный фон")

    if positive_share - negative_share >= 0.2:
        opening = "Общее восприятие скорее положительное"
    elif negative_share - positive_share >= 0.2:
        opening = "Общее восприятие скорее проблемное"
    else:
        opening = "Общее восприятие смешанное"

    strength_text = (
        f"Клиенты чаще всего положительно отмечают «{strength_aspects[0]['aspect']}»"
        if strength_aspects
        else "Устойчивой сильной стороны пока не видно"
    )
    problem_text = (
        f"главная зона риска — «{problem_aspects[0]['aspect']}»"
        if problem_aspects
        else "критичная повторяющаяся зона риска не обнаружена"
    )

    return (
        f"{opening}: из {total} отзывов {positive} позитивных, {negative} негативных и {neutral} нейтральных. "
        f"Эмоциональный фон: {dominant_emotion}. {strength_text}, при этом {problem_text}. "
        "Для управленческого решения важнее смотреть не только на среднюю тональность, но и на повторяемость аспектов."
    )


def build_aspect_insights(
    aspect_sentiments: dict[str, Counter[str]],
    aspect_counter: Counter[str],
    aspect_examples: dict[str, dict[str, list[str]]],
    total: int,
) -> list[dict[str, Any]]:
    insights = []
    for aspect, sentiments in aspect_sentiments.items():
        positive = sentiments.get("позитив", 0)
        negative = sentiments.get("негатив", 0)
        neutral = sentiments.get("нейтрально", 0)
        mentions = aspect_counter[aspect]
        if mentions == 0:
            continue
        if positive > negative * 1.4:
            status = "сильная сторона"
        elif negative > positive * 1.2:
            status = "зона риска"
        elif positive and negative:
            status = "поляризует"
        else:
            status = "наблюдать"
        insights.append(
            {
                "aspect": aspect,
                "status": status,
                "mentions": mentions,
                "positive": positive,
                "negative": negative,
                "neutral": neutral,
                "share": round(mentions / max(total, 1), 2),
                "explanation": build_aspect_explanation(
                    aspect,
                    aspect_examples.get(aspect, {}).get("позитив", []),
                    aspect_examples.get(aspect, {}).get("негатив", []),
                ),
            }
        )
    insights.sort(key=lambda item: (item["mentions"], item["negative"]), reverse=True)
    return insights[:8]


def source_display_name(source: str) -> str:
    labels = {
        "2gis_visible_text": "2ГИС",
        "yandex_eda_modal": "Яндекс Еда",
        "tophotels_visible_text": "TopHotels",
        "avito_visible_text": "Avito",
        "otzovik_visible": "Отзовик",
        "irecommend_visible": "IRecommend",
        "visible_page": "Страница",
        "visible_page_text": "Текст страницы",
        "selected_text": "Выделенный текст",
        "manual_input": "Ручной ввод",
        "demo": "Демо-данные",
    }
    return labels.get(source, str(source or "-").replace("_", " "))


def build_source_comparison(reviews: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "total": 0,
            "sentiments": Counter(),
            "emotions": Counter(),
            "aspects": Counter(),
            "ratings": [],
        }
    )

    for review in reviews:
        source = str(review.get("source") or "unknown")
        item = grouped[source]
        item["total"] += 1
        item["sentiments"][review.get("sentiment") or "нейтрально"] += 1
        emotion_label = (review.get("emotion") or {}).get("label")
        if emotion_label:
            item["emotions"][emotion_label] += 1
        if isinstance(review.get("rating"), (int, float)):
            item["ratings"].append(review["rating"])
        for aspect in review.get("aspects") or []:
            label = aspect.get("label")
            if label:
                item["aspects"][label] += 1

    comparison = []
    for source, item in grouped.items():
        total = item["total"]
        negative = item["sentiments"].get("негатив", 0)
        positive = item["sentiments"].get("позитив", 0)
        neutral = item["sentiments"].get("нейтрально", 0)
        negative_share = negative / max(total, 1)
        positive_share = positive / max(total, 1)
        average_rating = None
        if item["ratings"]:
            average_rating = round(sum(item["ratings"]) / len(item["ratings"]), 2)
        top_aspect, top_aspect_count = ("-", 0)
        if item["aspects"]:
            top_aspect, top_aspect_count = item["aspects"].most_common(1)[0]
        comparison.append(
            {
                "source": source,
                "label": source_display_name(source),
                "total": total,
                "positive": positive,
                "negative": negative,
                "neutral": neutral,
                "positive_share": round(positive_share, 2),
                "negative_share": round(negative_share, 2),
                "average_rating": average_rating,
                "dominant_emotion": dominant_label(item["emotions"], "смешанный фон"),
                "top_aspect": top_aspect,
                "top_aspect_count": top_aspect_count,
            }
        )

    comparison.sort(key=lambda item: (item["negative_share"], item["negative"], item["total"]), reverse=True)
    return comparison


def build_aspect_sentiment_matrix(
    aspect_sentiments: dict[str, Counter[str]],
    aspect_counter: Counter[str],
    total_reviews: int,
) -> list[dict[str, Any]]:
    rows = []
    for aspect, sentiments in aspect_sentiments.items():
        mentions = aspect_counter[aspect]
        if mentions == 0:
            continue
        positive = sentiments.get("позитив", 0)
        negative = sentiments.get("негатив", 0)
        neutral = sentiments.get("нейтрально", 0)
        risk_points = negative * 2 + neutral * 0.5 - positive * 0.35
        if negative > positive and negative >= 2:
            status = "риск"
        elif positive > negative:
            status = "сильная сторона"
        elif positive and negative:
            status = "спорный аспект"
        else:
            status = "наблюдать"
        rows.append(
            {
                "aspect": aspect,
                "mentions": mentions,
                "positive": positive,
                "negative": negative,
                "neutral": neutral,
                "share": round(mentions / max(total_reviews, 1), 2),
                "negative_share": round(negative / max(mentions, 1), 2),
                "status": status,
                "risk_points": round(max(risk_points, 0), 2),
            }
        )
    rows.sort(key=lambda item: (item["risk_points"], item["mentions"]), reverse=True)
    return rows


def build_risk_index(
    total: int,
    sentiment_counter: Counter[str],
    matrix: list[dict[str, Any]],
    source_comparison: list[dict[str, Any]],
) -> dict[str, Any]:
    if total == 0:
        return {
            "score": 0,
            "level": "нет данных",
            "drivers": [],
            "interpretation": "Для расчета индекса риска нужно добавить отзывы.",
        }

    negative_share = sentiment_counter.get("негатив", 0) / total
    risky_aspects = [row for row in matrix if row["status"] in {"риск", "спорный аспект"}]
    aspect_pressure = min(1.0, sum(row["negative"] for row in risky_aspects[:4]) / max(total, 1))
    source_pressure = max((source["negative_share"] for source in source_comparison), default=0)
    score = round(min(100, negative_share * 55 + aspect_pressure * 30 + source_pressure * 15))

    if score >= 70:
        level = "критичный"
    elif score >= 45:
        level = "высокий"
    elif score >= 25:
        level = "средний"
    else:
        level = "низкий"

    drivers = []
    if negative_share:
        drivers.append(f"негативных отзывов: {round(negative_share * 100)}%")
    if risky_aspects:
        drivers.append(f"главный аспект риска: {risky_aspects[0]['aspect']}")
    if source_comparison and len(source_comparison) > 1:
        drivers.append(f"самый проблемный источник: {source_comparison[0]['label']}")
    if not drivers:
        drivers.append("выраженных факторов риска не найдено")

    return {
        "score": score,
        "level": level,
        "drivers": drivers[:3],
        "interpretation": f"Индекс риска {score}/100: уровень «{level}».",
    }


def dominant_label(counter: Counter[str], tie_label: str) -> str:
    if not counter:
        return tie_label
    most_common = counter.most_common(2)
    if len(most_common) > 1 and most_common[0][1] == most_common[1][1]:
        return tie_label
    return most_common[0][0]


def analyze_reviews(payload: dict[str, Any]) -> dict[str, Any]:
    object_name = infer_object_name(payload)
    page_text = str(payload.get("page_text") or "")
    object_type = str(payload.get("object_type") or "").strip() or guess_object_type(f"{object_name} {page_text}")
    source_url = str(payload.get("source_url") or "")
    review_limit = read_review_limit(payload)
    inline_reviews = inline_reviews_from_payload(payload, limit=review_limit)
    if inline_reviews:
        reviews = inline_reviews
        source_info = {
            "mode": "visible_page",
            "label": "видимые отзывы со страницы",
            "message": "Проанализированы отзывы, которые расширение смогло прочитать на открытой странице.",
        }
    else:
        external_source = is_external_source_url(source_url)
        reviews = [] if external_source else find_reviews(object_name, page_text, limit=review_limit)
        source_info = {
            "mode": "demo_reviews" if reviews else "no_reviews",
            "label": "демонстрационная база" if reviews else "нет отзывов",
            "message": (
                "Использована демонстрационная база, потому что реальный источник отзывов пока не подключен."
                if reviews
                else (
                    "Отзывы с этой внешней страницы не извлечены. Открой вкладку отзывов, дождись загрузки и повтори анализ."
                    if external_source
                    else "Для этого объекта реальные отзывы не извлечены. Открой страницу с видимыми отзывами или подключи источник данных."
                )
            ),
        }

    analyzed_reviews = []
    emotion_counter: Counter[str] = Counter()
    sentiment_counter: Counter[str] = Counter()
    aspect_counter: Counter[str] = Counter()
    aspect_sentiments: dict[str, Counter[str]] = defaultdict(Counter)
    examples_by_aspect: dict[str, list[str]] = defaultdict(list)
    strength_examples_by_aspect: dict[str, list[str]] = defaultdict(list)
    aspect_examples: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))

    for index, review in enumerate(reviews, start=1):
        text = str(review.get("text", ""))
        rating = review.get("rating")
        numeric_rating = rating if isinstance(rating, (int, float)) else None
        sentiment = detect_sentiment(text, numeric_rating)
        emotion = reconcile_emotion_with_sentiment(detect_emotion(text, numeric_rating), sentiment, text, numeric_rating)
        aspects = extract_aspects(text)

        emotion_counter[emotion["label"]] += 1
        sentiment_counter[sentiment] += 1
        for aspect in aspects:
            label = aspect["label"]
            aspect_counter[label] += 1
            aspect_sentiments[label][sentiment] += 1
            if len(aspect_examples[label][sentiment]) < 4:
                aspect_examples[label][sentiment].append(text)
            if sentiment == "негатив" and len(examples_by_aspect[label]) < 2:
                examples_by_aspect[label].append(text)
            if sentiment == "позитив" and len(strength_examples_by_aspect[label]) < 2:
                strength_examples_by_aspect[label].append(text)

        analyzed_reviews.append(
            {
                "id": index,
                "text": text,
                "rating": numeric_rating,
                "source": review.get("source", "demo"),
                "emotion": emotion,
                "sentiment": sentiment,
                "aspects": aspects,
            }
        )

    total = len(analyzed_reviews)
    top_problem_aspects = []
    for aspect, sentiments in aspect_sentiments.items():
        negative = sentiments.get("негатив", 0)
        if negative:
            top_problem_aspects.append(
                {
                    "aspect": aspect,
                    "negative_reviews": negative,
                    "mentions": aspect_counter[aspect],
                    "share": round(negative / max(total, 1), 2),
                    "examples": examples_by_aspect[aspect],
                    "explanation": build_aspect_explanation(
                        aspect,
                        aspect_examples.get(aspect, {}).get("позитив", []),
                        aspect_examples.get(aspect, {}).get("негатив", []),
                    ),
                    "recommendation": problem_recommendation(aspect),
                }
            )
    top_problem_aspects.sort(key=lambda item: (item["negative_reviews"], item["mentions"]), reverse=True)

    top_strength_aspects = []
    for aspect, sentiments in aspect_sentiments.items():
        positive = sentiments.get("позитив", 0)
        negative = sentiments.get("негатив", 0)
        if positive and positive > negative:
            top_strength_aspects.append(
                {
                    "aspect": aspect,
                    "positive_reviews": positive,
                    "mentions": aspect_counter[aspect],
                    "share": round(positive / max(total, 1), 2),
                    "examples": strength_examples_by_aspect[aspect],
                    "explanation": build_aspect_explanation(
                        aspect,
                        aspect_examples.get(aspect, {}).get("позитив", []),
                        aspect_examples.get(aspect, {}).get("негатив", []),
                    ),
                    "recommendation": strength_recommendation(aspect),
                }
            )
    top_strength_aspects.sort(key=lambda item: (item["positive_reviews"], item["mentions"]), reverse=True)

    average_rating = None
    ratings = [item["rating"] for item in analyzed_reviews if isinstance(item.get("rating"), (int, float))]
    if ratings:
        average_rating = round(sum(ratings) / len(ratings), 2)

    risk_summary = build_risk_summary(total, sentiment_counter, top_problem_aspects)
    executive_summary = build_executive_summary(total, sentiment_counter, top_problem_aspects, top_strength_aspects)
    overall_review = build_overall_review(total, sentiment_counter, emotion_counter, top_problem_aspects, top_strength_aspects)
    aspect_insights = build_aspect_insights(aspect_sentiments, aspect_counter, aspect_examples, total)
    source_comparison = build_source_comparison(analyzed_reviews)
    aspect_sentiment_matrix = build_aspect_sentiment_matrix(aspect_sentiments, aspect_counter, total)
    risk_index = build_risk_index(total, sentiment_counter, aspect_sentiment_matrix, source_comparison)
    confidence = min(0.95, 0.55 + math.log(max(total, 1), 10) * 0.2)
    return {
        "object": {
            "name": object_name,
            "type": object_type,
            "source_url": source_url,
        },
        "source": source_info,
        "summary": {
            "total_reviews": total,
            "average_rating": average_rating,
            "dominant_emotion": dominant_label(emotion_counter, "смешанный фон"),
            "dominant_sentiment": dominant_label(sentiment_counter, "смешанная"),
            "confidence": round(confidence if total else 0, 2),
            "positive_reviews": sentiment_counter.get("позитив", 0),
            "negative_reviews": sentiment_counter.get("негатив", 0),
            "neutral_reviews": sentiment_counter.get("нейтрально", 0),
            "positive_share": round(sentiment_counter.get("позитив", 0) / max(total, 1), 2) if total else 0,
            "negative_share": round(sentiment_counter.get("негатив", 0) / max(total, 1), 2) if total else 0,
            "executive_summary": executive_summary,
            "overall_review": overall_review,
            "review_limit": review_limit,
            **risk_summary,
        },
        "distributions": {
            "emotions": dict(emotion_counter),
            "sentiments": dict(sentiment_counter),
            "aspects": dict(aspect_counter.most_common()),
        },
        "problem_aspects": top_problem_aspects[:5],
        "strength_aspects": top_strength_aspects[:5],
        "aspect_insights": aspect_insights,
        "source_comparison": source_comparison,
        "aspect_sentiment_matrix": aspect_sentiment_matrix,
        "risk_index": risk_index,
        "model_info": build_model_info(),
        "reviews": analyzed_reviews,
    }
